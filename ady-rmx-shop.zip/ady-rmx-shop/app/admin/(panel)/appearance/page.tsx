"use client";

import { useEffect, useState } from "react";
import { FloppyDisk, Plus, Trash } from "@phosphor-icons/react";
import {
  api,
  Section,
  Field,
  TextInput,
  TextArea,
  Toggle,
  MediaInput,
  Notice,
} from "@/components/admin/ui";
import {
  FEATURE_ICONS,
  FEATURE_ICON_KEYS,
  SOCIAL_ICONS,
  SOCIAL_KEYS,
  normalizeIconKey,
  FeatureIcon,
  SocialIcon,
} from "@/components/site/FeatureIcon";
import { mix, rgba } from "@/lib/color";

const ACCENTS = [
  { name: "Mint", v: "#00e5b0" },
  { name: "Mint Terang", v: "#00f3bc" },
  { name: "Emas", v: "#e8c15a" },
  { name: "Cyan", v: "#38bdf8" },
  { name: "Ungu", v: "#a78bfa" },
  { name: "Hijau", v: "#34d399" },
  { name: "Merah", v: "#fb7185" },
  { name: "Orange", v: "#fb923c" },
  { name: "Sakura", v: "#f7a8c4" },
];
const BGS = [
  { name: "Hitam Pekat", v: "#060607" },
  { name: "Obsidian", v: "#0a0c10" },
  { name: "Midnight", v: "#0b1020" },
  { name: "Charcoal", v: "#141416" },
  { name: "Forest", v: "#0a1410" },
];

export default function AdminAppearance() {
  const [s, setS] = useState<any>(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api("/api/admin/settings")
      .then((j) => {
        const st = j.settings;
        st.features = (st.features || []).map((f: any) => ({
          ...f,
          icon: normalizeIconKey(f.icon),
        }));
        st.socials = st.socials || [];
        setS(st);
      })
      .catch((e) => setErr(e.message));
  }, []);

  // Preview live tema di halaman admin
  useEffect(() => {
    if (!s) return;
    const el = document.documentElement;
    const vars: Record<string, string> = {
      "--brand": s.accentColor,
      "--brand-2": mix(s.accentColor, "#ffffff", 0.38),
      "--brand-dark": mix(s.accentColor, "#000000", 0.26),
      "--brand-soft": rgba(s.accentColor, 0.15),
      "--glow": rgba(s.accentColor, 0.22),
      "--bg-base": s.bgColor,
      "--bg-elev": mix(s.bgColor, "#ffffff", 0.18),
      "--bg-card": mix(s.bgColor, "#ffffff", 0.12),
    };
    for (const [k, v] of Object.entries(vars)) el.style.setProperty(k, v);
    return () => {
      for (const k of Object.keys(vars)) el.style.removeProperty(k);
    };
  }, [s?.accentColor, s?.bgColor]);

  if (!s)
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-40 rounded-3xl bg-w05" />
        ))}
      </div>
    );

  const set = (k: string, v: any) => {
    setS({ ...s, [k]: v });
    setMsg("");
  };

  const save = async () => {
    setSaving(true);
    setErr("");
    try {
      await api("/api/admin/settings", {
        method: "PATCH",
        body: {
          storeName: s.storeName,
          tagline: s.tagline,
          description: s.description,
          establishedYear: Number(s.establishedYear),
          logoUrl: s.logoUrl,
          bannerUrl: s.bannerUrl,
          announcementEnabled: !!s.announcementEnabled,
          announcementText: s.announcementText,
          popupEnabled: !!s.popupEnabled,
          popupImageUrl: s.popupImageUrl,
          popupTitle: s.popupTitle,
          popupSubtitle: s.popupSubtitle,
          popupCtaText: s.popupCtaText,
          popupCtaUrl: s.popupCtaUrl,
          features: s.features.map((f: any) => ({
            ...f,
            icon: normalizeIconKey(f.icon),
          })),
          accentColor: s.accentColor,
          bgColor: s.bgColor,
          bgType: s.bgType || "warna",
          bgMediaUrl: s.bgMediaUrl || "",
          bgOverlay: Number(s.bgOverlay ?? 70),
          socials: (s.socials || []).map((x: any) => ({
            key: x.key,
            label: x.label,
            url: x.url,
            active: !!x.active,
          })),
        },
      });
      setMsg("Tampilan berhasil disimpan!");
      setTimeout(() => window.location.reload(), 700);
    } catch (e: any) {
      setErr(e.message);
      setSaving(false);
    }
  };

  const setFeature = (i: number, k: string, v: string) => {
    const f = [...s.features];
    f[i] = { ...f[i], [k]: v };
    setS({ ...s, features: f });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">TAMPILAN</h1>
          <p className="text-xs text-muted">Identitas toko, banner & tema warna</p>
        </div>
        <button onClick={save} disabled={saving} className="btn btn-primary py-3 text-xs">
          <FloppyDisk size={15} weight="bold" /> {saving ? "Menyimpan..." : "Simpan Semua"}
        </button>
      </div>

      {/* Identitas */}
      <Section title="Identitas Toko" desc="Nama store bisa diganti kapan saja">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Nama Store *">
            <TextInput
              value={s.storeName}
              onChange={(e) => set("storeName", e.target.value)}
            />
          </Field>
          <Field label="Tagline">
            <TextInput value={s.tagline} onChange={(e) => set("tagline", e.target.value)} />
          </Field>
          <div className="md:col-span-2">
            <Field label="Deskripsi (footer & SEO)">
              <TextArea
                rows={2}
                value={s.description}
                onChange={(e) => set("description", e.target.value)}
              />
            </Field>
          </div>
          <Field label="Tahun Berdiri" hint="Untuk badge EST. dan statistik pengalaman">
            <TextInput
              type="number"
              min={2000}
              max={2100}
              value={s.establishedYear}
              onChange={(e) => set("establishedYear", e.target.value)}
            />
          </Field>
        </div>
        <div className="mt-4 grid gap-5 md:grid-cols-2">
          <Field label="Logo" hint="Kosongkan untuk memakai logo default bawaan">
            <MediaInput kind="image" value={s.logoUrl} onChange={(v) => set("logoUrl", v)} />
          </Field>
          <Field label="Banner Utama" hint="Kosongkan untuk memakai banner default bawaan">
            <MediaInput kind="image" value={s.bannerUrl} onChange={(v) => set("bannerUrl", v)} />
          </Field>
        </div>
      </Section>

      {/* Tema */}
      <Section title="Tema Warna" desc="Warna dasar seluruh situs — preview langsung di bawah">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <p className="label">Warna Aksen</p>
            <div className="mb-3 flex flex-wrap gap-2">
              {ACCENTS.map((a) => (
                <button
                  key={a.v}
                  type="button"
                  onClick={() => set("accentColor", a.v)}
                  className={`flex items-center gap-1.5 rounded-full border py-1 pl-1 pr-3 text-[10px] font-bold transition ${
                    s.accentColor === a.v
                      ? "border-brand bg-brand-soft !text-brand"
                      : "border-line text-muted"
                  }`}
                >
                  <span
                    className="h-5 w-5 rounded-full border border-white"
                    style={{ background: a.v }}
                  />
                  {a.name}
                </button>
              ))}
            </div>
            <input
              type="color"
              value={s.accentColor}
              onChange={(e) => set("accentColor", e.target.value)}
              className="h-12 w-full rounded-xl"
            />
          </div>
          <div>
            <p className="label">Warna Background</p>
            <div className="mb-3 flex flex-wrap gap-2">
              {BGS.map((b) => (
                <button
                  key={b.v}
                  type="button"
                  onClick={() => set("bgColor", b.v)}
                  className={`flex items-center gap-1.5 rounded-full border py-1 pl-1 pr-3 text-[10px] font-bold transition ${
                    s.bgColor === b.v
                      ? "border-brand bg-brand-soft !text-brand"
                      : "border-line text-muted"
                  }`}
                >
                  <span
                    className="h-5 w-5 rounded-full border border-white"
                    style={{ background: b.v }}
                  />
                  {b.name}
                </button>
              ))}
            </div>
            <input
              type="color"
              value={s.bgColor}
              onChange={(e) => set("bgColor", e.target.value)}
              className="h-12 w-full rounded-xl"
            />
          </div>
        </div>

        {/* Preview */}
        <div className="mt-5 overflow-hidden rounded-2xl p-5" style={{ background: s.bgColor }}>
          <div
            className="rounded-2xl p-4"
            style={{ background: mix(s.bgColor, "#ffffff", 0.12) }}
          >
            <p
              className="font-poster text-2xl tracking-wider"
              style={{ color: s.accentColor }}
            >
              {(s.storeName || "").toUpperCase()}
            </p>
            <p className="mt-1 text-[11px]" style={{ color: "#94a3b8" }}>
              {s.tagline}
            </p>
            <div className="mt-3 flex gap-2">
              <span
                className="rounded-xl px-4 py-2 text-[11px] font-extrabold"
                style={{
                  background: `linear-gradient(135deg, ${mix(
                    s.accentColor,
                    "#ffffff",
                    0.38
                  )}, ${s.accentColor})`,
                  color: "#14161c",
                }}
              >
                Beli Sekarang
              </span>
              <span
                className="rounded-xl border px-4 py-2 text-[11px] font-extrabold"
                style={{
                  borderColor: mix(s.bgColor, "#ffffff", 0.45),
                  color: "#f1f5f9",
                }}
              >
                Play Sample
              </span>
            </div>
          </div>
        </div>
      </Section>

      {/* Announcement */}
      <Section title="Pengumuman Berjalan" desc="Teks marquee di bagian atas situs">
        <Field label="Aktifkan Pengumuman">
          <div className="input-wrap justify-between">
            <TextInput
              value={s.announcementText}
              onChange={(e) => set("announcementText", e.target.value)}
              placeholder="Teks pengumuman..."
            />
            <Toggle
              on={!!s.announcementEnabled}
              onChange={(v) => set("announcementEnabled", v)}
            />
          </div>
        </Field>
      </Section>

      {/* Popup welcome */}
      <Section title="Popup Selamat Datang" desc="Muncul sekali untuk pengunjung baru">
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Judul Popup">
            <TextInput value={s.popupTitle} onChange={(e) => set("popupTitle", e.target.value)} />
          </Field>
          <Field label="Teks Tombol CTA">
            <TextInput
              value={s.popupCtaText}
              onChange={(e) => set("popupCtaText", e.target.value)}
            />
          </Field>
          <Field label="Sub Judul">
            <TextArea
              rows={2}
              value={s.popupSubtitle}
              onChange={(e) => set("popupSubtitle", e.target.value)}
            />
          </Field>
          <Field label="URL Tujuan CTA" hint="#produk / #request / link lain">
            <TextInput
              value={s.popupCtaUrl}
              onChange={(e) => set("popupCtaUrl", e.target.value)}
            />
          </Field>
          <div className="md:col-span-2">
            <Field label="Gambar Popup" hint="Kosongkan untuk memakai banner default">
              <MediaInput
                kind="image"
                value={s.popupImageUrl}
                onChange={(v) => set("popupImageUrl", v)}
              />
            </Field>
          </div>
          <Field label="Aktifkan Popup">
            <div className="input-wrap justify-between px-4 py-3">
              <span className="text-xs font-bold text-muted">
                {s.popupEnabled ? "Aktif" : "Nonaktif"}
              </span>
              <Toggle on={!!s.popupEnabled} onChange={(v) => set("popupEnabled", v)} />
            </div>
          </Field>
        </div>
      </Section>

      {/* Fitur unggulan */}
      <Section title="Fitur Unggulan" desc="Kartu keunggulan di landing page (maksimal 8)">
        <div className="space-y-3">
          {s.features.map((f: any, i: number) => (
            <div key={i} className="rounded-2xl border border-line bg-w03 p-3.5">
              <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-start">
                <div className="grid gap-3 sm:grid-cols-2">
                  <TextInput
                    value={f.title}
                    placeholder="Judul fitur"
                    onChange={(e) => setFeature(i, "title", e.target.value)}
                  />
                  <TextInput
                    value={f.desc}
                    placeholder="Deskripsi singkat"
                    onChange={(e) => setFeature(i, "desc", e.target.value)}
                  />
                </div>
                <button
                  onClick={() =>
                    setS({ ...s, features: s.features.filter((_: any, x: number) => x !== i) })
                  }
                  className="badge-chip !bg-danger-soft !text-rose-400"
                  type="button"
                >
                  <Trash size={11} weight="fill" /> Hapus
                </button>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {FEATURE_ICON_KEYS.map((key) => {
                  const on = f.icon === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      title={FEATURE_ICONS[key].label}
                      onClick={() => setFeature(i, "icon", key)}
                      className={`grid h-9 w-9 place-items-center rounded-xl border transition ${
                        on
                          ? "border-transparent bg-gradient-to-br from-brand-2 to-brand !text-[#14161c] shadow-glow"
                          : "border-line bg-elev text-muted hover:text-brand"
                      }`}
                    >
                      <FeatureIcon name={key} size={17} weight={on ? "fill" : "duotone"} />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          {s.features.length < 8 && (
            <button
              onClick={() =>
                setS({ ...s, features: [...s.features, { icon: "star", title: "", desc: "" }] })
              }
              className="btn btn-dark w-full py-3 text-xs"
              type="button"
            >
              <Plus size={14} weight="bold" /> Tambah Fitur
            </button>
          )}
        </div>
      </Section>

      {/* Background situs */}
      <Section title="Background Situs" desc="Pakai warna solid, gambar, atau video upload sendiri">
        <div className="mb-4 grid grid-cols-3 gap-2">
          {[
            { k: "warna", t: "Warna Solid" },
            { k: "gambar", t: "Gambar" },
            { k: "video", t: "Video" },
          ].map((o) => (
            <button
              key={o.k}
              type="button"
              onClick={() => set("bgType", o.k)}
              className={`rounded-xl border px-3 py-2.5 text-[11px] font-bold transition ${
                (s.bgType || "warna") === o.k
                  ? "border-brand bg-brand-soft !text-brand"
                  : "border-line bg-elev text-muted hover:text-ink"
              }`}
            >
              {o.t}
            </button>
          ))}
        </div>

        {(s.bgType === "gambar" || s.bgType === "video") && (
          <>
            <Field
              label={s.bgType === "video" ? "Video Background" : "Gambar Background"}
              hint={
                s.bgType === "video"
                  ? "MP4/Webm maks 60MB — diputar berulang tanpa suara"
                  : "Disarankan resolusi besar (mis. 1920x1080)"
              }
            >
              <MediaInput
                kind={(s.bgType === "video" ? "video" : "image") as any}
                value={s.bgMediaUrl}
                onChange={(v) => set("bgMediaUrl", v)}
              />
            </Field>
            <div className="mt-4">
              <Field label={"Overlay Gelap: " + (s.bgOverlay ?? 70) + "%"} hint="Semakin tinggi semakin gelap agar teks mudah dibaca">
                <input
                  type="range"
                  min={0}
                  max={90}
                  value={s.bgOverlay ?? 70}
                  onChange={(e) => set("bgOverlay", Number(e.target.value))}
                  className="seek w-full"
                  style={{
                    background:
                      "linear-gradient(to right, var(--brand) " +
                      ((s.bgOverlay ?? 70) / 90) * 100 +
                      "%, var(--line-strong) " +
                      ((s.bgOverlay ?? 70) / 90) * 100 +
                      "%)",
                  }}
                />
              </Field>
            </div>
          </>
        )}
      </Section>

      {/* Sosmed dinamis */}
      <Section title="Ikuti Kami (Sosial Media)" desc="Tambah, edit, aktif/nonaktifkan per akun — tampil di footer">
        <div className="space-y-3">
          {(s.socials || []).map((soc: any, i: number) => (
            <div key={i} className={"grid gap-2 rounded-2xl border border-line bg-w03 p-3 sm:grid-cols-[auto_1fr_1.6fr_auto_auto] sm:items-center " + (!soc.active ? "opacity-50" : "")}>
              <select
                className="input-wrap w-full appearance-none sm:w-36"
                value={soc.key}
                onChange={(e) => {
                  const arr = [...s.socials];
                  arr[i] = { ...arr[i], key: e.target.value };
                  setS({ ...s, socials: arr });
                }}
              >
                {SOCIAL_KEYS.map((k) => (
                  <option key={k} value={k}>
                    {SOCIAL_ICONS[k].label}
                  </option>
                ))}
              </select>
              <TextInput
                value={soc.label}
                placeholder="Label"
                onChange={(e) => {
                  const arr = [...s.socials];
                  arr[i] = { ...arr[i], label: e.target.value };
                  setS({ ...s, socials: arr });
                }}
              />
              <TextInput
                value={soc.url}
                placeholder="https://..."
                onChange={(e) => {
                  const arr = [...s.socials];
                  arr[i] = { ...arr[i], url: e.target.value };
                  setS({ ...s, socials: arr });
                }}
              />
              <Toggle
                on={!!soc.active}
                onChange={(v) => {
                  const arr = [...s.socials];
                  arr[i] = { ...arr[i], active: v };
                  setS({ ...s, socials: arr });
                }}
              />
              <button
                type="button"
                onClick={() =>
                  setS({ ...s, socials: s.socials.filter((_: any, x: number) => x !== i) })
                }
                className="badge-chip justify-center !bg-danger-soft !text-rose-400"
              >
                <Trash size={11} weight="fill" />
              </button>
            </div>
          ))}
          {(s.socials || []).length < 12 && (
            <button
              type="button"
              onClick={() =>
                setS({
                  ...s,
                  socials: [
                    ...(s.socials || []),
                    { key: "instagram", label: "Instagram", url: "", active: true },
                  ],
                })
              }
              className="btn btn-dark w-full py-3 text-xs"
            >
              <Plus size={14} weight="bold" /> Tambah Sosial Media
            </button>
          )}
          {!!(s.socials || []).filter((x: any) => x.active && x.url).length && (
            <div className="flex flex-wrap gap-2 pt-1">
              {s.socials
                .filter((x: any) => x.active && x.url)
                .map((x: any, i: number) => (
                  <span key={i} className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-elev text-brand">
                    <SocialIcon name={x.key} size={18} />
                  </span>
                ))}
            </div>
          )}
        </div>
      </Section>

      <Notice msg={msg || err} ok={!!msg && !err} />

      <button
        onClick={save}
        disabled={saving}
        className="btn btn-primary sticky bottom-4 w-full lg:w-auto lg:px-10"
      >
        <FloppyDisk size={16} weight="bold" /> {saving ? "Menyimpan..." : "Simpan Semua Perubahan"}
      </button>
    </div>
  );
}
