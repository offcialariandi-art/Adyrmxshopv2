"use client";

import { useEffect, useState } from "react";
import { Key } from "@phosphor-icons/react";
import { api, Section, Field, TextInput, Notice } from "@/components/admin/ui";

export default function AdminAccount() {
  const [username, setUsername] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm2, setConfirm2] = useState("");
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    api("/api/admin/settings").then((j) => setUsername(j.settings.adminUser)).catch(() => {});
  }, []);

  const save = async () => {
    setErr(""); setMsg("");
    if (newPassword && newPassword !== confirm2)
      return setErr("Konfirmasi password baru tidak sama.");
    try {
      await api("/api/admin/account", {
        method: "PATCH",
        body: { currentPassword, username, newPassword: newPassword || undefined },
      });
      setMsg("Akun berhasil diperbarui.");
      setCurrentPassword(""); setNewPassword(""); setConfirm2("");
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <div>
        <h1 className="font-poster text-4xl tracking-wide">AKUN ADMIN</h1>
        <p className="text-xs text-muted">Ubah username & password login</p>
      </div>

      <Section title="Ganti Kredensial" desc="Verifikasi dengan password saat ini">
        <div className="space-y-4">
          <Field label="Username Baru">
            <TextInput value={username} onChange={(e) => setUsername(e.target.value)} minLength={3} />
          </Field>
          <Field label="Password Saat Ini *">
            <TextInput type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="Wajib diisi untuk konfirmasi" />
          </Field>
          <Field label="Password Baru" hint="Min. 6 karakter — kosongkan jika tidak ingin ganti">
            <TextInput type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </Field>
          <Field label="Ulangi Password Baru">
            <TextInput type="password" value={confirm2} onChange={(e) => setConfirm2(e.target.value)} />
          </Field>
          <Notice msg={msg || err} ok={!!msg && !err} />
          <button onClick={save} className="btn btn-primary w-full">
            <Key size={15} weight="bold" /> Simpan Perubahan
          </button>
        </div>
      </Section>

      <p className="text-center text-[10px] leading-relaxed text-dim">
        Tips keamanan: gunakan password unik dan jangan dibagikan. Sesi login aktif selama 7 hari.
      </p>
    </div>
  );
}
