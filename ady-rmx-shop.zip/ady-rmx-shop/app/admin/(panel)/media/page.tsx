"use client";

import { useCallback, useEffect, useState } from "react";
import { Trash, Copy, Images } from "@phosphor-icons/react";
import { api, Notice, confirmDialog, Section } from "@/components/admin/ui";

const kb = (n: number) =>
  n > 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";

export default function AdminMedia() {
  const [files, setFiles] = useState<any[]>([]);
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState("");

  const load = useCallback(() => {
    api("/api/admin/media").then((j) => setFiles(j.files)).catch((e) => setErr(e.message));
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-poster text-4xl tracking-wide">MEDIA LIBRARY</h1>
        <p className="text-xs text-muted">{files.length} file upload (gambar & audio)</p>
      </div>

      <Notice msg={err} />

      {files.length === 0 ? (
        <Section title="Belum ada file"><p className="text-xs text-dim">Upload gambar/audio dari menu Produk atau Tampilan akan muncul di sini.</p></Section>
      ) : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
          {files.map((f) => (
            <div key={f.name} className="card overflow-hidden p-0">
              <div className="grid h-32 place-items-center bg-w03 p-3">
                {f.isAudio ? (
                  <audio src={f.url} controls preload="none" className="w-full" />
                ) : f.isVideo ? (
                  <video src={f.url} className="h-full w-full rounded-lg object-cover" muted loop autoPlay playsInline />
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={f.url} alt={f.name} loading="lazy" className="h-full w-full rounded-lg object-cover" />
                )}
              </div>
              <div className="space-y-2 p-3">
                <p className="truncate font-mono text-[10px] text-dim">{f.name}</p>
                <p className="text-[10px] font-bold text-muted">{kb(f.size)}</p>
                <div className="flex gap-1.5">
                  <button onClick={() => {
                    navigator.clipboard?.writeText(location.origin + f.url);
                    setCopied(f.name);
                    setTimeout(() => setCopied(""), 1500);
                  }} className="badge-chip flex-1 border border-line bg-elev text-[9px] text-muted hover:text-brand">
                    <Copy size={10} /> {copied === f.name ? "Tersalin!" : "Salin URL"}
                  </button>
                  <button onClick={async () => {
                    if (!confirmDialog(`Hapus file ${f.name}?`)) return;
                    await api(`/api/admin/media?name=${f.name}`, { method: "DELETE" });
                    load();
                  }} className="badge-chip !bg-danger-soft !text-rose-400">
                    <Trash size={10} weight="fill" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
