"use client";

import { useRef, useState } from "react";
import { DownloadSimple, UploadSimple, WarningOctagon } from "@phosphor-icons/react";
import { api, Section, Notice, confirmDialog } from "@/components/admin/ui";

export default function AdminBackup() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");
  const [resetText, setResetText] = useState("");
  const [busy, setBusy] = useState(false);

  const exportJson = () => {
    window.location.href = "/api/admin/backup";
    setMsg("Backup diunduh.");
  };

  const importJson = async (file: File) => {
    if (!confirmDialog("Restore akan MENGGANTI semua data saat ini. Lanjutkan?")) return;
    setErr(""); setMsg("");
    try {
      const text = await file.text();
      const body = JSON.parse(text);
      const j = await api("/api/admin/backup", { method: "POST", body });
      setMsg(j.message || "Restore berhasil.");
    } catch (e: any) {
      setErr("Import gagal: " + e.message);
    }
  };

  const resetFactory = async () => {
    if (resetText !== "RESET") return setErr('Ketik "RESET" dengan huruf besar untuk konfirmasi.');
    if (!confirmDialog("Semua produk, kontak, testimoni, FAQ & request akan DIHAPUS permanen. Yakin?")) return;
    setBusy(true);
    try {
      await api("/api/admin/backup?confirm=RESET", { method: "DELETE" });
      setMsg("Data berhasil direset ke pengaturan awal.");
      setResetText("");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <div>
        <h1 className="font-poster text-4xl tracking-wide">BACKUP & RESET</h1>
        <p className="text-xs text-muted">Amankan data toko secara berkala</p>
      </div>

      <Section title="Export Backup" desc="Unduh seluruh data sebagai JSON">
        <button onClick={exportJson} className="btn btn-primary w-full">
          <DownloadSimple size={16} weight="bold" /> Unduh Backup (.json)
        </button>
      </Section>

      <Section title="Import / Restore" desc="Pulihkan dari file backup — data saat ini akan diganti">
        <input ref={fileRef} type="file" accept="application/json" className="hidden"
          onChange={(e) => e.target.files?.[0] && importJson(e.target.files[0])} />
        <button onClick={() => fileRef.current?.click()} className="btn btn-dark w-full">
          <UploadSimple size={16} weight="bold" /> Pilih File Backup
        </button>
      </Section>

      <Section title="Zona Berbahaya" desc="Reset pabrik menghapus semua data ke pengaturan awal">
        <div className="rounded-2xl border border-rose-400 bg-danger-soft p-4">
          <p className="flex items-center gap-2 text-xs font-bold text-rose-400">
            <WarningOctagon size={16} weight="fill" /> Tindakan tidak dapat dibatalkan
          </p>
          <div className="input-wrap mt-3 !border-rose-400">
            <input
              className="input font-mono"
              placeholder='Ketik "RESET" untuk konfirmasi'
              value={resetText}
              onChange={(e) => setResetText(e.target.value)}
            />
          </div>
          <button onClick={resetFactory} disabled={busy || resetText !== "RESET"}
            className="btn mt-3 w-full bg-rose-500 text-white disabled:opacity-40">
            {busy ? "Mereset..." : "Reset Pabrik"}
          </button>
        </div>
      </Section>

      <Notice msg={msg || err} ok={!!msg && !err} />
    </div>
  );
}
