"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  PencilSimple,
  Trash,
  ArrowClockwise,
  EyeSlash,
  Eye,
  MagnifyingGlass,
  Package,
  MusicNotes,
} from "@phosphor-icons/react";
import {
  api,
  Field,
  TextInput,
  Toggle,
  MediaInput,
  Modal,
  Notice,
  confirmDialog,
  ArrowBtns,
} from "@/components/admin/ui";
import type { ProductData } from "@/components/site/types";

const EMPTY = {
  title: "",
  price: 0,
  oldPrice: 0,
  sold: 0,
  category: "Umum",
  thumbnailUrl: "",
  audioUrl: "",
  badge: "",
  active: true,
};

export default function AdminProducts() {
  const [items, setItems] = useState<ProductData[]>([]);
  const [view, setView] = useState<"all" | "active" | "trash">("all");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [edit, setEdit] = useState<any>(null);
  const [isNew, setIsNew] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    setLoading(true);
    api(`/api/admin/products?view=${view}&q=${encodeURIComponent(q)}`)
      .then((j) => setItems(j.items))
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, [view, q]);

  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    if (!edit.title?.trim()) return setErr("Judul wajib diisi.");
    try {
      if (isNew) await api("/api/admin/products", { method: "POST", body: edit });
      else await api(`/api/admin/products/${edit._id}`, { method: "PATCH", body: edit });
      setMsg(isNew ? "Produk ditambahkan." : "Produk diperbarui.");
      setEdit(null);
      load();
    } catch (e: any) {
      setErr(e.message);
    }
  };

  const move = async (idx: number, dir: -1 | 1) => {
    const arr = [...items];
    const t = idx + dir;
    if (t < 0 || t >= arr.length) return;
    [arr[idx], arr[t]] = [arr[t], arr[idx]];
    setItems(arr);
    await api("/api/admin/reorder", {
      method: "POST",
      body: { target: "products", ids: arr.map((x) => x._id) },
    });
    load();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">PRODUK</h1>
          <p className="text-xs text-muted">Kelola katalog projek & sample audio</p>
        </div>
        <button
          onClick={() => {
            setEdit({ ...EMPTY });
            setIsNew(true);
            setErr("");
          }}
          className="btn btn-primary py-3 text-xs"
        >
          <Plus size={15} weight="bold" /> Tambah Produk
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="input-wrap max-w-[240px]">
          <MagnifyingGlass size={15} weight="bold" className="ml-1 text-dim" />
          <input
            className="input"
            placeholder="Cari produk..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        {(["all", "active", "trash"] as const).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`badge-chip py-1.5 transition ${
              view === v ? "!bg-brand !text-[#14161c]" : "border border-line bg-elev text-muted"
            }`}
          >
            {v === "all" ? "Semua" : v === "active" ? "Aktif" : "Sampah"}
          </button>
        ))}
        <Notice msg={msg || err} ok={!!msg && !err} />
      </div>

      <div className="space-y-2.5">
        {loading ? (
          [...Array(4)].map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-3xl bg-w05" />
          ))
        ) : items.length === 0 ? (
          <div className="card p-10 text-center">
            <Package size={32} weight="duotone" className="mx-auto text-dim" />
            <p className="mt-3 text-sm font-bold">Belum ada produk di sini.</p>
          </div>
        ) : (
          items.map((p, i) => (
            <div
              key={p._id}
              className={`card flex items-center gap-3 p-3 ${p.deletedAt ? "opacity-60" : ""}`}
            >
              <ArrowBtns
                onUp={() => move(i, -1)}
                onDown={() => move(i, 1)}
                first={i === 0}
                last={i === items.length - 1}
              />
              {p.thumbnailUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={p.thumbnailUrl}
                  alt=""
                  className="h-16 w-16 shrink-0 rounded-xl object-cover"
                />
              ) : (
                <span className="grid h-16 w-16 shrink-0 place-items-center rounded-xl bg-elev text-dim">
                  <MusicNotes size={24} weight="duotone" />
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold">{p.title}</p>
                <p className="mt-0.5 text-[11px] font-semibold text-brand">
                  Rp {new Intl.NumberFormat("id-ID").format(p.price)}
                  {(p.oldPrice || 0) > p.price && (
                    <span className="ml-1.5 font-medium text-dim line-through">
                      Rp {new Intl.NumberFormat("id-ID").format(p.oldPrice || 0)}
                    </span>
                  )}
                  <span className="ml-2 font-medium normal-case text-dim">
                    Terjual {p.sold} · {p.category}
                  </span>
                </p>
                {p.audioUrl && (
                  <audio
                    src={p.audioUrl}
                    controls
                    preload="none"
                    className="mt-1.5 h-8 max-w-[260px]"
                  />
                )}
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5 sm:flex-row sm:items-center">
                {!p.deletedAt ? (
                  <>
                    {p.active ? (
                      <button
                        onClick={async () => {
                          await api(`/api/admin/products/${p._id}`, {
                            method: "PATCH",
                            body: { active: false },
                          });
                          load();
                        }}
                        className="grid h-8 w-8 place-items-center rounded-full border border-line text-emerald-400 transition hover:border-emerald-400"
                        aria-label="Sembunyikan produk"
                      >
                        <Eye size={15} />
                      </button>
                    ) : (
                      <button
                        onClick={async () => {
                          await api(`/api/admin/products/${p._id}`, {
                            method: "PATCH",
                            body: { active: true },
                          });
                          load();
                        }}
                        className="grid h-8 w-8 place-items-center rounded-full border border-line text-dim transition hover:border-brand hover:text-brand"
                        aria-label="Tampilkan produk"
                      >
                        <EyeSlash size={15} />
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setEdit({ ...EMPTY, ...p });
                        setIsNew(false);
                        setErr("");
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:border-brand hover:text-brand"
                      aria-label="Edit"
                    >
                      <PencilSimple size={14} />
                    </button>
                    <button
                      onClick={async () => {
                        if (!confirmDialog(`Pindahkan "${p.title}" ke sampah?`)) return;
                        await api(`/api/admin/products/${p._id}`, { method: "DELETE" });
                        load();
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:border-rose-400 hover:text-rose-400"
                      aria-label="Hapus"
                    >
                      <Trash size={14} />
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={async () => {
                        await api(`/api/admin/products/${p._id}`, {
                          method: "PATCH",
                          body: { action: "restore" },
                        });
                        load();
                      }}
                      className="badge-chip !bg-ok-soft !text-emerald-400"
                    >
                      <ArrowClockwise size={11} weight="bold" /> Restore
                    </button>
                    <button
                      onClick={async () => {
                        if (!confirmDialog(`Hapus PERMANEN "${p.title}"?`)) return;
                        await api(`/api/admin/products/${p._id}?permanent=1`, {
                          method: "DELETE",
                        });
                        load();
                      }}
                      className="badge-chip !bg-danger-soft !text-rose-400"
                    >
                      Hapus permanen
                    </button>
                  </>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal edit */}
      {edit && (
        <Modal
          title={isNew ? "Tambah Produk" : "Edit Produk"}
          onClose={() => setEdit(null)}
          wide
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Field label="Judul Produk *">
                <TextInput
                  value={edit.title}
                  onChange={(e) => setEdit({ ...edit, title: e.target.value })}
                  placeholder="Mis. STYLE HAPPY TEAM"
                />
              </Field>
            </div>
            <Field label="Harga (Rp)">
              <TextInput
                type="number"
                min={0}
                value={edit.price}
                onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })}
              />
            </Field>
            <Field
              label="Harga Sebelum Diskon (opsional)"
              hint="Isi lebih besar dari harga untuk badge diskon otomatis"
            >
              <TextInput
                type="number"
                min={0}
                value={edit.oldPrice}
                onChange={(e) => setEdit({ ...edit, oldPrice: Number(e.target.value) })}
              />
            </Field>
            <Field label="Jumlah Terjual">
              <TextInput
                type="number"
                min={0}
                value={edit.sold}
                onChange={(e) => setEdit({ ...edit, sold: Number(e.target.value) })}
              />
            </Field>
            <Field label="Kategori" hint="Dipakai untuk tab filter di landing page">
              <TextInput
                value={edit.category}
                onChange={(e) => setEdit({ ...edit, category: e.target.value })}
              />
            </Field>
            <Field label="Badge Manual" hint="Kosongkan = otomatis NEW/HOT">
              <select
                className="input-wrap appearance-none"
                value={edit.badge}
                onChange={(e) => setEdit({ ...edit, badge: e.target.value })}
              >
                <option value="">Otomatis</option>
                <option value="NEW">NEW</option>
                <option value="HOT">HOT</option>
              </select>
            </Field>
            <Field label="Status Aktif">
              <div className="input-wrap justify-between px-4 py-2.5">
                <span className="text-xs font-bold text-muted">
                  {edit.active ? "Tampil di toko" : "Disembunyikan"}
                </span>
                <Toggle on={edit.active} onChange={(v) => setEdit({ ...edit, active: v })} />
              </div>
            </Field>
            <div className="sm:col-span-2">
              <Field label="Thumbnail / Gambar Produk">
                <MediaInput
                  kind="image"
                  value={edit.thumbnailUrl}
                  onChange={(url) => setEdit({ ...edit, thumbnailUrl: url })}
                />
              </Field>
            </div>
            <div className="sm:col-span-2">
              <Field
                label="Sample Audio (preview pembeli)"
                hint="MP3 pendek disarankan agar loading cepat"
              >
                <MediaInput
                  kind="audio"
                  value={edit.audioUrl}
                  onChange={(url) => setEdit({ ...edit, audioUrl: url })}
                />
              </Field>
            </div>
          </div>

          <Notice msg={err} />

          <div className="mt-6 flex gap-2.5">
            <button onClick={() => setEdit(null)} className="btn btn-dark flex-1">
              Batal
            </button>
            <button onClick={save} className="btn btn-primary flex-1">
              Simpan
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
