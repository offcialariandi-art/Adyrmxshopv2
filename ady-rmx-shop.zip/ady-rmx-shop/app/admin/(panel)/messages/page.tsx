"use client";

import { useEffect, useState } from "react";
import { FloppyDisk, X, Plus } from "@phosphor-icons/react";
import {
  api,
  Section,
  Field,
  TextArea,
  Notice,
} from "@/components/admin/ui";

const PLACEHOLDERS = ["{store}", "{produk}", "{harga}", "{nama}", "{catatan}", "{kategori}", "{style}"];

function TagList({
  label,
  hint,
  values,
  onChange,
}: {
  label: string;
  hint?: string;
  values: string[];
  onChange: (v: string[]) => void;
}) {
  const [draft, setDraft] = useState("");
  const add = () => {
    const v = draft.trim();
    if (!v || values.includes(v)) return;
    onChange([...values, v]);
    setDraft("");
  };
  return (
    <Field label={label} hint={hint}>
      <div className="input-wrap flex-wrap py-2">
        {values.map((v) => (
          <span key={v} className="badge-chip bg-brand-soft !text-brand">
            {v}
            <button type="button" onClick={() => onChange(values.filter((x) => x !== v))} aria-label={"Hapus " + v}>
              <X size={9} weight="bold" />
            </button>
          </span>
        ))}
        <input
          className="input min-w-[120px]"
          style={{ width: "auto", flex: 1 }}
          placeholder="Ketik lalu Enter..."
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          onBlur={add}
        />
      </div>
    </Field>
  );
}

export default function AdminMessages() {
  const [s, setS] = useState<any>(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    api("/api/admin/settings").then((j) => setS(j.settings)).catch((e) => setErr(e.message));
  }, []);

  if (!s) return <div className="h-64 animate-pulse rounded-3xl bg-w05" />;

  const insert = (field: string, ph: string) => {
    setS({ ...s, [field]: (s[field] || "") + ph });
  };

  const save = async () => {
    try {
      await api("/api/admin/settings", {
        method: "PATCH",
        body: {
          orderTemplate: s.orderTemplate,
          requestTemplate: s.requestTemplate,
          requestCategories: s.requestCategories,
          requestStyles: s.requestStyles,
        },
      });
      setMsg("Template pesan tersimpan.");
    } catch (e: any) {
      setErr(e.message);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-poster text-4xl tracking-wide">PESAN TEMPLATE</h1>
        <p className="text-xs text-muted">Isi pesan otomatis saat pembeli klik order via WA/TG — bebas diubah termasuk tambah/hapus emoji</p>
      </div>

      <Section
        title="Template Pesan Order Produk"
        desc="Dikirim saat pembeli menekan Beli Sekarang. Klik placeholder untuk menyisipkan."
      >
        <div className="mb-2 flex flex-wrap gap-1">
          {PLACEHOLDERS.map((p) => (
            <button key={p} onClick={() => insert("orderTemplate", p)}
              className="badge-chip border border-line bg-elev font-mono text-[9px] text-muted hover:text-brand">
              <Plus size={8} weight="bold" /> {p}
            </button>
          ))}
        </div>
        <TextArea rows={7} value={s.orderTemplate} onChange={(e) => setS({ ...s, orderTemplate: e.target.value })} className="font-mono text-[12px]" />
      </Section>

      <Section
        title="Template Pesan Request Projek"
        desc="Dikirim setelah pengunjung submit form request"
      >
        <div className="mb-2 flex flex-wrap gap-1">
          {PLACEHOLDERS.map((p) => (
            <button key={p} onClick={() => insert("requestTemplate", p)}
              className="badge-chip border border-line bg-elev font-mono text-[9px] text-muted hover:text-brand">
              <Plus size={8} weight="bold" /> {p}
            </button>
          ))}
        </div>
        <TextArea rows={7} value={s.requestTemplate} onChange={(e) => setS({ ...s, requestTemplate: e.target.value })} className="font-mono text-[12px]" />
      </Section>

      <Section title="Opsi Form Request" desc="Pilihan dropdown kategori & style di landing page">
        <div className="space-y-4">
          <TagList label="Kategori" values={s.requestCategories || []} onChange={(v) => setS({ ...s, requestCategories: v })} />
          <TagList label="Style" values={s.requestStyles || []} onChange={(v) => setS({ ...s, requestStyles: v })} />
        </div>
      </Section>

      <Notice msg={msg || err} ok={!!msg && !err} />
      <button onClick={save} className="btn btn-primary sticky bottom-4 lg:px-10">
        <FloppyDisk size={16} weight="bold" /> Simpan Template
      </button>
    </div>
  );
}
