"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, PencilSimple, Trash, Question } from "@phosphor-icons/react";
import {
  api,
  Section,
  Field,
  TextInput,
  TextArea,
  Modal,
  Notice,
  confirmDialog,
} from "@/components/admin/ui";

export default function AdminFaqs() {
  const [items, setItems] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [isNew, setIsNew] = useState(false);
  const [err, setErr] = useState("");

  const load = useCallback(() => {
    api("/api/admin/faqs").then((j) => setItems(j.items)).catch((e) => setErr(e.message));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    try {
      if (isNew) await api("/api/admin/faqs", { method: "POST", body: edit });
      else await api(`/api/admin/faqs/${edit._id}`, { method: "PATCH", body: edit });
      setEdit(null); load();
    } catch (e: any) { setErr(e.message); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">FAQ</h1>
          <p className="text-xs text-muted">Pertanyaan yang sering diajukan</p>
        </div>
        <button onClick={() => { setEdit({ q: "", a: "" }); setIsNew(true); setErr(""); }}
          className="btn btn-primary py-3 text-xs">
          <Plus size={15} weight="bold" /> Tambah
        </button>
      </div>

      <Notice msg={err} />

      {items.length === 0 ? (
        <Section title="Belum ada FAQ">
          <p className="text-xs text-dim">Contoh: &ldquo;Bagaimana cara order?&rdquo;, &ldquo;Format file apa yang dikirim?&rdquo;</p>
        </Section>
      ) : (
        <div className="space-y-2.5">
          {items.map((f) => (
            <div key={f._id} className="card flex items-center gap-3 p-4">
              <Question size={18} weight="duotone" className="shrink-0 text-brand" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold">{f.q}</p>
                <p className="truncate text-[11px] text-dim">{f.a}</p>
              </div>
              <button onClick={() => { setEdit({ ...f }); setIsNew(false); }}
                className="grid h-8 w-8 place-items-center rounded-full border border-line hover:border-brand hover:text-brand">
                <PencilSimple size={13} />
              </button>
              <button onClick={async () => {
                if (!confirmDialog("Hapus FAQ ini?")) return;
                await api(`/api/admin/faqs/${f._id}`, { method: "DELETE" });
                load();
              }} className="grid h-8 w-8 place-items-center rounded-full border border-line hover:border-rose-400 hover:text-rose-400">
                <Trash size={13} />
              </button>
            </div>
          ))}
        </div>
      )}

      {edit && (
        <Modal title={isNew ? "Tambah FAQ" : "Edit FAQ"} onClose={() => setEdit(null)} wide>
          <div className="space-y-4">
            <Field label="Pertanyaan *">
              <TextInput value={edit.q} onChange={(e) => setEdit({ ...edit, q: e.target.value })} placeholder="Mis. Bagaimana cara order?" />
            </Field>
            <Field label="Jawaban *">
              <TextArea rows={4} value={edit.a} onChange={(e) => setEdit({ ...edit, a: e.target.value })} />
            </Field>
            <Notice msg={err} />
            <div className="flex gap-2.5">
              <button onClick={() => setEdit(null)} className="btn btn-dark flex-1">Batal</button>
              <button onClick={save} className="btn btn-primary flex-1">Simpan</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
