"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  WhatsappLogo,
  TelegramLogo,
  PencilSimple,
  Trash,
} from "@phosphor-icons/react";
import {
  api,
  Field,
  TextInput,
  Toggle,
  Modal,
  Notice,
  confirmDialog,
  ArrowBtns,
  Section,
} from "@/components/admin/ui";

export default function AdminContacts() {
  const [items, setItems] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [isNew, setIsNew] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    api("/api/admin/contacts").then((j) => setItems(j.items)).catch((e) => setErr(e.message));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    try {
      if (isNew) await api("/api/admin/contacts", { method: "POST", body: edit });
      else await api(`/api/admin/contacts/${edit._id}`, { method: "PATCH", body: edit });
      setEdit(null); setMsg("Kontak disimpan."); load();
    } catch (e: any) { setErr(e.message); }
  };

  const move = async (i: number, dir: -1 | 1) => {
    const arr = [...items];
    const t = i + dir;
    if (t < 0 || t >= arr.length) return;
    [arr[i], arr[t]] = [arr[t], arr[i]];
    setItems(arr);
    await api("/api/admin/reorder", { method: "POST", body: { target: "contacts", ids: arr.map((x) => x._id) } });
    load();
  };

  const waActive = items.filter((c) => c.active && c.type === "whatsapp").length;
  const tgActive = items.filter((c) => c.active && c.type === "telegram").length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">KONTAK ORDER</h1>
          <p className="text-xs text-muted">{waActive} WhatsApp aktif · {tgActive} Telegram aktif</p>
        </div>
        <button
          onClick={() => { setEdit({ type: "whatsapp", label: "", value: "", active: true }); setIsNew(true); setErr(""); }}
          className="btn btn-primary py-3 text-xs"
        >
          <Plus size={15} weight="bold" /> Tambah Kontak
        </button>
      </div>

      <Notice msg={msg || err} ok={!!msg && !err} />

      <Section title="Cara Kerja Tombol Order" desc="Logika pilihan order di landing page">
        <ul className="space-y-2 text-xs leading-relaxed text-muted">
          <li>• <b className="text-ink">WA + TG aktif</b> → klik Beli → bottom sheet pilihan WhatsApp & Telegram.</li>
          <li>• <b className="text-ink">Hanya WA / hanya TG</b> → langsung dibuka tanpa pilihan.</li>
          <li>• Bisa pasang banyak nomor sekaligus — semua nomor aktif muncul di daftar.</li>
        </ul>
      </Section>

      <div className="space-y-2.5">
        {items.length === 0 ? (
          <div className="card p-10 text-center text-sm text-muted">Belum ada kontak. Tambahkan nomor WhatsApp / username Telegram.</div>
        ) : (
          items.map((c, i) => (
            <div key={c._id} className={`card flex items-center gap-3 p-3.5 ${!c.active ? "opacity-50" : ""}`}>
              <ArrowBtns onUp={() => move(i, -1)} onDown={() => move(i, 1)} first={i === 0} last={i === items.length - 1} />
              <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-full ${c.type === "whatsapp" ? "bg-ok-soft text-emerald-400" : "bg-info-soft text-sky-400"}`}>
                {c.type === "whatsapp" ? <WhatsappLogo size={22} weight="fill" /> : <TelegramLogo size={22} weight="fill" />}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold">{c.label}</p>
                <p className="truncate font-mono text-[11px] text-dim">
                  {c.type === "whatsapp" ? `+${c.value.replace(/[^0-9]/g, "")}` : `@${c.value.replace(/^@/, "")}`}
                </p>
              </div>
              <Toggle on={c.active} onChange={async () => {
                await api(`/api/admin/contacts/${c._id}`, { method: "PATCH", body: { active: !c.active } });
                load();
              }} />
              <button
                onClick={() => { setEdit({ ...c }); setIsNew(false); setErr(""); setMsg(""); }}
                className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:border-brand hover:text-brand"
              >
                <PencilSimple size={14} />
              </button>
              <button
                onClick={async () => {
                  if (!confirmDialog(`Hapus kontak "${c.label}"?`)) return;
                  await api(`/api/admin/contacts/${c._id}`, { method: "DELETE" });
                  load();
                }}
                className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:border-rose-400 hover:text-rose-400"
              >
                <Trash size={14} />
              </button>
            </div>
          ))
        )}
      </div>

      {edit && (
        <Modal title={isNew ? "Tambah Kontak" : "Edit Kontak"} onClose={() => setEdit(null)}>
          <div className="space-y-4">
            <Field label="Tipe Kontak">
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setEdit({ ...edit, type: "whatsapp" })}
                  className={`btn border ${edit.type === "whatsapp" ? "!bg-ok-soft !text-emerald-400 !border-emerald-400" : "btn-dark"}`}>
                  <WhatsappLogo size={16} weight="fill" /> WhatsApp
                </button>
                <button type="button" onClick={() => setEdit({ ...edit, type: "telegram" })}
                  className={`btn border ${edit.type === "telegram" ? "!bg-info-soft !text-sky-400 !border-sky-400" : "btn-dark"}`}>
                  <TelegramLogo size={16} weight="fill" /> Telegram
                </button>
              </div>
            </Field>
            <Field label="Label (nama yang ditampilkan)">
              <TextInput value={edit.label} placeholder="Mis. Admin Toko / CS 1" onChange={(e) => setEdit({ ...edit, label: e.target.value })} />
            </Field>
            <Field
              label={edit.type === "whatsapp" ? "Nomor WhatsApp *" : "Username Telegram *"}
              hint={edit.type === "whatsapp" ? "Format internasional tanpa + dan spasi, mis. 6281234567890" : "Tanpa @, mis. adyrmx_admin"}
            >
              <TextInput value={edit.value} placeholder={edit.type === "whatsapp" ? "62812xxxxxxx" : "username_tg"} onChange={(e) => setEdit({ ...edit, value: e.target.value })} />
            </Field>
            <Field label="Status Aktif">
              <div className="input-wrap justify-between px-4 py-3">
                <span className="text-xs font-bold text-muted">{edit.active ? "Aktif — dipakai untuk order" : "Nonaktif"}</span>
                <Toggle on={edit.active} onChange={(v) => setEdit({ ...edit, active: v })} />
              </div>
            </Field>
            <Notice msg={err} />
            <div className="flex gap-2.5 pt-1">
              <button onClick={() => setEdit(null)} className="btn btn-dark flex-1">Batal</button>
              <button onClick={save} className="btn btn-primary flex-1">Simpan</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
