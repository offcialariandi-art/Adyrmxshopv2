"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Package,
  ShoppingCart,
  HandTap,
  Tray,
  Plus,
} from "@phosphor-icons/react";
import { api } from "@/components/admin/ui";

export default function AdminDashboard() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    api("/api/admin/stats")
      .then(setData)
      .catch((e) => setErr(e.message));
  }, []);

  if (err) return <p className="text-sm text-rose-400">{err}</p>;
  if (!data) return <Skeleton />;

  const s = data.stats;
  const maxCount = Math.max(1, ...data.chart.map((c: any) => c.count));
  const cards = [
    { label: "Produk Aktif", val: `${s.activeProducts}/${s.totalProducts}`, Icon: Package, color: "text-brand" },
    { label: "Total Terjual", val: s.totalSold, Icon: ShoppingCart, color: "text-emerald-400" },
    { label: "Klik Order (7 hari)", val: s.clicks7d, Icon: HandTap, color: "text-sky-400" },
    { label: "Request Baru", val: s.requestsNew, Icon: Tray, color: "text-amber-400" },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">DASHBOARD</h1>
          <p className="text-xs text-muted">Ringkasan performa toko hari ini</p>
        </div>
        <Link href="/admin/products" className="btn btn-primary py-3 text-xs">
          <Plus size={15} weight="bold" /> Tambah Produk
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        {cards.map(({ label, val, Icon, color }, i) => (
          <div
            key={i}
            className="card anim-fade-up relative overflow-hidden p-4 transition hover:border-line-strong"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <span
              className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-70"
              style={{
                background:
                  "linear-gradient(to right, transparent, var(--brand), transparent)",
              }}
            />
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-display text-2xl font-bold md:text-3xl">{val}</p>
                <p className="mt-1 truncate text-[9px] font-extrabold uppercase tracking-[0.16em] text-dim">
                  {label}
                </p>
              </div>
              <span
                className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${color}`}
                style={{ background: "var(--brand-soft)" }}
              >
                <Icon size={17} weight="duotone" />
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.3fr_1fr]">
        <div className="card p-5">
          <h2 className="text-sm font-extrabold">Klik Order — 14 Hari Terakhir</h2>
          <p className="mb-4 text-[11px] text-muted">
            Setiap pembeli menekan tombol chat tercatat di sini.
          </p>
          <div className="flex h-40 items-end gap-1.5">
            {data.chart.map((d: any) => (
              <div key={d.date} className="group flex flex-1 flex-col items-center gap-1.5">
                <span className="rounded-md bg-elev px-1.5 py-0.5 font-mono text-[9px] font-bold text-brand opacity-0 transition group-hover:opacity-100">
                  {d.count}
                </span>
                <div
                  className="chart-col w-full rounded-t-md bg-gradient-to-t from-brand-dark to-brand"
                  style={{ height: `${Math.max(4, (d.count / maxCount) * 100)}%` }}
                />
                <span className="hidden truncate font-mono text-[8px] text-dim sm:block">
                  {d.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-extrabold">Request Terbaru</h2>
            <Link
              href="/admin/requests"
              className="text-[10px] font-bold text-brand hover:underline"
            >
              Lihat semua →
            </Link>
          </div>
          {data.latestRequests.length === 0 ? (
            <p className="py-6 text-center text-xs text-dim">Belum ada request masuk.</p>
          ) : (
            <ul className="space-y-2.5">
              {data.latestRequests.map((r: any) => (
                <li key={r._id} className="flex items-start gap-2.5 rounded-xl bg-w03 p-3">
                  <span
                    className={`badge-chip shrink-0 ${
                      r.status === "baru"
                        ? "!bg-danger-soft !text-rose-400"
                        : r.status === "diproses"
                        ? "!bg-warn-soft !text-amber-400"
                        : "!bg-ok-soft !text-emerald-400"
                    }`}
                  >
                    {r.status.toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-xs font-bold">{r.songTitle}</p>
                    <p className="truncate text-[10px] text-dim">
                      {r.category || "-"} · {r.style || "-"} ·{" "}
                      {r.buyerName || "Tanpa nama"}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

function Skeleton() {
  return (
    <div className="animate-pulse space-y-5">
      <div className="h-10 w-52 rounded-xl bg-w05" />
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-24 rounded-3xl bg-w05" />
        ))}
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="h-64 rounded-3xl bg-w05" />
        <div className="h-64 rounded-3xl bg-w05" />
      </div>
    </div>
  );
}
