"use client";

import { useCallback, useEffect, useState } from "react";
import { Trash, MusicNotes } from "@phosphor-icons/react";
import { api, Notice, confirmDialog } from "@/components/admin/ui";

const STATUSES = ["baru", "diproses", "selesai"] as const;

export default function AdminRequests() {
  const [items, setItems] = useState<any[]>([]);
  const [filter, setFilter] = useState("");
  const [err, setErr] = useState("");

  const load = useCallback(() => {
    api(`/api/admin/requests${filter ? `?status=${filter}` : ""}`)
      .then((j) => setItems(j.items))
      .catch((e) => setErr(e.message));
  }, [filter]);
  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-poster text-4xl tracking-wide">REQUEST MASUK</h1>
        <p className="text-xs text-muted">Form request projek dari pengunjung</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {[["", "Semua"], ...STATUSES.map((s) => [s, s.toUpperCase()])].map(([v, l]: any) => (
          <button key={v} onClick={() => setFilter(v)}
            className={`badge-chip py-1.5 transition ${filter === v ? "!bg-brand !text-[#14161c]" : "border border-line bg-elev text-muted"}`}>
            {l}
          </button>
        ))}
        <Notice msg={err} />
      </div>

      {items.length === 0 ? (
        <div className="card p-10 text-center text-sm text-muted">Belum ada request.</div>
      ) : (
        <div className="space-y-2.5">
          {items.map((r) => (
            <div key={r._id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-sm font-extrabold">
                    <MusicNotes size={15} weight="duotone" className="shrink-0 text-brand" />
                    {r.songTitle}
                  </p>
                  <p className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-muted">
                    <span>Kategori: {r.category || "-"}</span>
                    <span>Style: {r.style || "-"}</span>
                    <span>Nama: {r.buyerName || "Tanpa nama"}</span>
                    <span className="font-mono">{new Date(r.createdAt).toLocaleString("id-ID")}</span>
                  </p>
                  {r.note && <p className="mt-1.5 rounded-lg bg-w05 px-2.5 py-1.5 text-[11px] italic text-dim">&ldquo;{r.note}&rdquo;</p>}
                </div>
                <div className="flex items-center gap-2">
                  <select value={r.status} onChange={async (e) => {
                    await api(`/api/admin/requests/${r._id}`, { method: "PATCH", body: { status: e.target.value } });
                    load();
                  }}
                    className={`input-wrap w-auto appearance-none py-2 text-[10px] font-extrabold ${r.status === "baru" ? "!text-rose-400" : r.status === "diproses" ? "!text-amber-400" : "!text-emerald-400"}`}
                    style={{ width: "auto" }}>
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>{s.toUpperCase()}</option>
                    ))}
                  </select>
                  <button onClick={async () => {
                    if (!confirmDialog("Hapus request ini?")) return;
                    await api(`/api/admin/requests/${r._id}`, { method: "DELETE" });
                    load();
                  }} className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:border-rose-400 hover:text-rose-400">
                    <Trash size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
