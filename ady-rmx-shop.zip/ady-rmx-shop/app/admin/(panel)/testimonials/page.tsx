"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, PencilSimple, Trash, Star, CheckCircle } from "@phosphor-icons/react";
import {
  api,
  Section,
  Field,
  TextInput,
  TextArea,
  Toggle,
  MediaInput,
  Modal,
  Notice,
  confirmDialog,
} from "@/components/admin/ui";

export default function AdminTestimonials() {
  const [items, setItems] = useState<any[]>([]);
  const [edit, setEdit] = useState<any>(null);
  const [isNew, setIsNew] = useState(false);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"all" | "pending" | "live">("all");

  const load = useCallback(() => {
    api("/api/admin/testimonials")
      .then((j) => setItems(j.items))
      .catch((e) => setErr(e.message));
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    try {
      if (isNew) await api("/api/admin/testimonials", { method: "POST", body: edit });
      else
        await api(`/api/admin/testimonials/${edit._id}`, { method: "PATCH", body: edit });
      setEdit(null);
      load();
    } catch (e: any) {
      setErr(e.message);
    }
  };

  const filtered =
    tab === "all"
      ? items
      : tab === "pending"
      ? items.filter((x) => x.status === "pending")
      : items.filter((x) => x.status !== "pending");

  const count = (v: "all" | "pending" | "live") =>
    v === "all"
      ? items.length
      : v === "pending"
      ? items.filter((x) => x.status === "pending").length
      : items.filter((x) => x.status !== "pending").length;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-poster text-4xl tracking-wide">TESTIMONI</h1>
          <p className="text-xs text-muted">
            Kelola testimoni & setujui kiriman pengunjung
          </p>
        </div>
        <button
          onClick={() => {
            setEdit({ name: "", message: "", rating: 5, avatarUrl: "", show: true });
            setIsNew(true);
            setErr("");
          }}
          className="btn btn-primary py-3 text-xs"
        >
          <Plus size={15} weight="bold" /> Tambah Manual
        </button>
      </div>

      {/* Tab */}
      <div className="flex flex-wrap gap-2">
        {(
          [
            ["all", "Semua"],
            ["pending", "Menunggu Review"],
            ["live", "Tayang"],
          ] as const
        ).map(([v, l]) => (
          <button
            key={v}
            onClick={() => setTab(v)}
            className={`badge-chip py-1.5 transition ${
              tab === v ? "!bg-brand !text-[#14161c]" : "border border-line bg-elev text-muted"
            }`}
          >
            {l} ({count(v)})
          </button>
        ))}
      </div>

      <Notice msg={err} />

      {filtered.length === 0 ? (
        <Section title="Tidak ada testimoni di tab ini">
          <p className="text-xs text-dim">
            Testimoni kiriman pengunjung muncul di tab Menunggu Review.
          </p>
        </Section>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((t) => (
            <div key={t._id} className={`card p-4 ${!t.show || t.status === "pending" ? "opacity-60" : ""}`}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex gap-0.5 text-brand">
                  {Array.from({ length: t.rating || 0 }).map((_, i) => (
                    <Star key={i} size={12} weight="fill" />
                  ))}
                </div>
                {t.status === "pending" && (
                  <span className="badge-chip !bg-warn-soft !text-amber-400">
                    MENUNGGU REVIEW
                  </span>
                )}
              </div>
              <p className="mt-2 line-clamp-3 min-h-[36px] text-xs leading-relaxed text-muted">
                &ldquo;{t.message}&rdquo;
              </p>
              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-xs font-bold">{t.name}</span>
                  <div className="flex shrink-0 items-center gap-1.5">
                    {t.status === "pending" && (
                      <button
                        onClick={async () => {
                          await api(`/api/admin/testimonials/${t._id}`, {
                            method: "PATCH",
                            body: { status: "approved", show: true },
                          });
                          load();
                        }}
                        className="badge-chip !bg-ok-soft !text-emerald-400"
                        title="Setujui & tampilkan"
                      >
                        <CheckCircle size={11} weight="fill" /> Setujui
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex items-center justify-between border-t border-line pt-2.5">
                  <Toggle
                    on={!!t.show}
                    onChange={async () => {
                      await api(`/api/admin/testimonials/${t._id}`, {
                        method: "PATCH",
                        body: { show: !t.show },
                      });
                      load();
                    }}
                  />
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => {
                        setEdit({
                          ...t,
                          status: t.status || "approved",
                        });
                        setIsNew(false);
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full border border-line hover:border-brand hover:text-brand"
                      aria-label="Edit"
                    >
                      <PencilSimple size={13} />
                    </button>
                    <button
                      onClick={async () => {
                        if (!confirmDialog("Hapus testimoni ini?")) return;
                        await api(`/api/admin/testimonials/${t._id}`, {
                          method: "DELETE",
                        });
                        load();
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full border border-line hover:border-rose-400 hover:text-rose-400"
                      aria-label="Hapus"
                    >
                      <Trash size={13} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {edit && (
        <Modal
          title={isNew ? "Tambah Testimoni (manual)" : "Edit Testimoni"}
          onClose={() => setEdit(null)}
        >
          <div className="space-y-4">
            <Field label="Nama Pembeli *">
              <TextInput
                value={edit.name}
                onChange={(e) => setEdit({ ...edit, name: e.target.value })}
              />
            </Field>
            <Field label="Pesan Testimoni *">
              <TextArea
                rows={3}
                value={edit.message}
                onChange={(e) => setEdit({ ...edit, message: e.target.value })}
              />
            </Field>
            <Field label={`Rating: ${edit.rating} bintang`}>
              <input
                type="range"
                min={1}
                max={5}
                value={edit.rating}
                onChange={(e) => setEdit({ ...edit, rating: Number(e.target.value) })}
                className="seek w-full"
                style={{
                  background:
                    "linear-gradient(to right, var(--brand) " +
                    ((edit.rating - 1) / 4) * 100 +
                    "%, var(--line-strong) " +
                    ((edit.rating - 1) / 4) * 100 +
                    "%)",
                }}
              />
            </Field>
            <Field label="Foto Profil (opsional)">
              <MediaInput
                kind="image"
                value={edit.avatarUrl}
                onChange={(v) => setEdit({ ...edit, avatarUrl: v })}
              />
            </Field>
            <Field label="Status Tayang">
              <div className="input-wrap justify-between px-4 py-3">
                <span className="text-xs font-bold text-muted">
                  {edit.show ? "Tampil di landing page" : "Disembunyikan"}
                </span>
                <Toggle on={!!edit.show} onChange={(v) => setEdit({ ...edit, show: v })} />
              </div>
            </Field>
            <Notice msg={err} />
            <div className="flex gap-2.5">
              <button onClick={() => setEdit(null)} className="btn btn-dark flex-1">
                Batal
              </button>
              <button onClick={save} className="btn btn-primary flex-1">
                Simpan
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
