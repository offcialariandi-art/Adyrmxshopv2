"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LockKey, User, SignIn } from "@phosphor-icons/react";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErr("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error);
      router.replace("/admin");
    } catch (e: any) {
      setErr(e.message);
      setLoading(false);
    }
  };

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden p-5">
      <div
        className="hero-blob h-[380px] w-[380px] -top-24 left-1/2 -translate-x-1/2 opacity-60"
        style={{ background: "var(--glow)" }}
      />
      <div className="hero-grid absolute inset-0" />
      <form onSubmit={submit} className="card anim-pop relative w-full max-w-sm p-7 shadow-soft-lg">
        <div className="mb-6 text-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo-default.svg"
            alt="logo"
            className="mx-auto h-16 w-16 rounded-full border-2 border-brand shadow-glow"
          />
          <h1 className="mt-4 font-poster text-3xl tracking-widest">ADMIN PANEL</h1>
          <p className="text-xs text-muted">Masuk untuk mengelola toko</p>
        </div>

        <div className="space-y-3.5">
          <div>
            <label className="label">Username</label>
            <div className="input-wrap">
              <User size={15} weight="bold" className="ml-1 shrink-0 text-dim" />
              <input
                className="input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username admin"
                autoFocus
                required
              />
            </div>
          </div>
          <div>
            <label className="label">Password</label>
            <div className="input-wrap">
              <LockKey size={15} weight="bold" className="ml-1 shrink-0 text-dim" />
              <input
                type="password"
                className="input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
          </div>
        </div>

        {err && (
          <p className="anim-fade mt-3 rounded-xl border border-rose-500 bg-danger-soft px-3 py-2 text-center text-xs font-bold text-rose-400">
            {err}
          </p>
        )}

        <button type="submit" disabled={loading} className="btn btn-primary mt-6 w-full">
          <SignIn size={16} weight="bold" />
          {loading ? "Memproses..." : "Masuk"}
        </button>

        <p className="mt-4 text-center text-[10px] text-dim">
          Default: <b>ady</b> / <b>ady123</b> — segera ganti di menu Akun.
        </p>
      </form>
    </div>
  );
}
