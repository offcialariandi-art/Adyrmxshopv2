import { connectDB } from "@/lib/db";
import { Product, Contact, Testimonial, Faq } from "@/models";
import { getPublicSettings } from "@/lib/settings";
import { SiteApp } from "@/components/site/SiteApp";

export const dynamic = "force-dynamic";

export default async function Home() {
  await connectDB();
  const [settings, products, contacts, testimonials, faqs] = await Promise.all([
    getPublicSettings(),
    Product.find({ deletedAt: null, active: true })
      .sort({ order: 1, createdAt: -1 })
      .lean(),
    Contact.find().sort({ order: 1 }).lean(),
    Testimonial.find({ show: true, status: "approved" })
      .sort({ order: 1 })
      .lean(),
    Faq.find().sort({ order: 1 }).lean(),
  ]);

  return (
    <SiteApp
      settings={JSON.parse(JSON.stringify(settings))}
      products={JSON.parse(JSON.stringify(products))}
      contacts={JSON.parse(JSON.stringify(contacts))}
      testimonials={JSON.parse(JSON.stringify(testimonials))}
      faqs={JSON.parse(JSON.stringify(faqs))}
    />
  );
}
