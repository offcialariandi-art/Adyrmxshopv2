import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { z } from "zod";
import { ensureSeed } from "@/lib/settings";
import { signSession, SESSION_COOKIE } from "@/lib/auth";
import { ok, bad, rateLimit, clientIp } from "@/lib/api";

const Body = z.object({ username: z.string().min(1), password: z.string().min(1) });

export async function POST(req: Request) {
  const ip = clientIp(req);
  if (!rateLimit(`login:${ip}`, 8, 15 * 60_000)) {
    return bad("Terlalu banyak percobaan. Coba lagi dalam 15 menit.", 429);
  }

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Username dan password wajib diisi.");

  const doc = await ensureSeed();
  const validUser = parsed.data.username === doc!.adminUser;
  const validPass =
    validUser && bcrypt.compareSync(parsed.data.password, doc!.adminHash);

  if (!validUser || !validPass) {
    return bad("Username atau password salah.", 401);
  }

  const token = await signSession({ role: "admin", user: doc!.adminUser });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 86400,
    path: "/",
  });

  return ok();
}
