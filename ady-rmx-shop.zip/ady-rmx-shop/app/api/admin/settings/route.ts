import { z } from "zod";
import { ensureSeed } from "@/lib/settings";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const doc = await ensureSeed();
  const o = doc!.toObject();
  delete (o as any).adminHash;
  return ok({ settings: o });
}

const Feature = z.object({
  icon: z.string().max(20),
  title: z.string().max(60),
  desc: z.string().max(300),
});

const Patch = z.object({
  storeName: z.string().min(1).max(60).optional(),
  tagline: z.string().max(120).optional(),
  description: z.string().max(600).optional(),
  logoUrl: z.string().max(500).optional(),
  bannerUrl: z.string().max(500).optional(),
  establishedYear: z.number().int().min(2000).max(2100).optional(),
  announcementEnabled: z.boolean().optional(),
  announcementText: z.string().max(300).optional(),
  popupEnabled: z.boolean().optional(),
  popupImageUrl: z.string().max(500).optional(),
  popupTitle: z.string().max(80).optional(),
  popupSubtitle: z.string().max(200).optional(),
  popupCtaText: z.string().max(40).optional(),
  popupCtaUrl: z.string().max(300).optional(),
  features: z.array(Feature).max(8).optional(),
  accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  bgType: z.enum(["warna", "gambar", "video"]).optional(),
  bgMediaUrl: z.string().max(500).optional(),
  bgOverlay: z.number().int().min(0).max(90).optional(),
  socials: z
    .array(
      z.object({
        key: z.string().min(1).max(20),
        label: z.string().min(1).max(30),
        url: z.string().min(1).max(300),
        active: z.boolean(),
      })
    )
    .max(12)
    .optional(),
  bgColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  instagram: z.string().max(300).optional(),
  tiktok: z.string().max(300).optional(),
  youtube: z.string().max(300).optional(),
  facebook: z.string().max(300).optional(),
  requestCategories: z.array(z.string().max(40)).max(20).optional(),
  requestStyles: z.array(z.string().max(40)).max(20).optional(),
  orderTemplate: z.string().max(1500).optional(),
  requestTemplate: z.string().max(1500).optional(),
});

export async function PATCH(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = Patch.safeParse(await req.json().catch(() => null));
  if (!parsed.success)
    return bad("Data tidak valid: " + parsed.error.issues[0]?.message);

  const doc = await ensureSeed();
  Object.assign(doc!, parsed.data);
  await doc!.save();
  return ok();
}
