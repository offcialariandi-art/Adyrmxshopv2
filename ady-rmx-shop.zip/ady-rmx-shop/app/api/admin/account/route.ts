import bcrypt from "bcryptjs";
import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Setting } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad, clientIp, rateLimit } from "@/lib/api";

const Body = z.object({
  currentPassword: z.string().min(1),
  username: z.string().min(3).max(40).optional(),
  newPassword: z.string().min(6).max(100).optional(),
});

export async function PATCH(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  if (!rateLimit(`account:${clientIp(req)}`, 10, 60_000))
    return bad("Terlalu sering. Tunggu sebentar.", 429);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data tidak valid (password min. 6 karakter).");

  await connectDB();
  const doc = await Setting.findOne({ key: "main" });
  if (!doc) return bad("Setting tidak ditemukan.", 500);

  if (!bcrypt.compareSync(parsed.data.currentPassword, doc.adminHash))
    return bad("Password saat ini salah.", 401);

  if (parsed.data.username) doc.adminUser = parsed.data.username.trim();
  if (parsed.data.newPassword)
    doc.adminHash = bcrypt.hashSync(parsed.data.newPassword, 10);

  await doc.save();
  return ok({ username: doc.adminUser });
}
