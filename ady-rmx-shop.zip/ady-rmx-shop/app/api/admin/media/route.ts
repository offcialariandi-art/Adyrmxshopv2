import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";
import { listMedia, deleteMedia } from "@/lib/media";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const files = (await listMedia()).map((f) => ({
    ...f,
    // Jaminan: size selalu ada (BSON Binary vs Buffer bisa beda bentuk)
    size: Number(f.size) || 0,
  }));
  return ok({ files });
}

export async function DELETE(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const name = new URL(req.url).searchParams.get("name") || "";
  if (!/^[A-Za-z0-9._-]+$/.test(name)) return bad("Nama file tidak valid.");
  await deleteMedia(name);
  return ok();
}
