import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Contact } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();
  const items = await Contact.find().sort({ order: 1 }).lean();
  return ok({ items });
}

const Body = z.object({
  type: z.enum(["whatsapp", "telegram"]),
  label: z.string().min(1).max(40),
  value: z.string().min(3).max(40),
  active: z.boolean().optional(),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    const msg =
      parsed.error.issues[0]?.path?.[0] === "value"
        ? "Nomor WA (format internasional, mis. 62812xxxx) atau username TG wajib diisi."
        : parsed.error.issues[0]?.message;
    return bad(msg || "Data kontak tidak valid.");
  }

  await connectDB();
  const max = await Contact.findOne({}, { order: 1 }).sort({ order: -1 }).lean();
  const item = await Contact.create({
    ...parsed.data,
    order: ((max as any)?.order ?? 0) + 1,
  });
  return ok({ item });
}
