import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Contact } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

const Patch = z.object({
  type: z.enum(["whatsapp", "telegram"]).optional(),
  label: z.string().min(1).max(40).optional(),
  value: z.string().min(3).max(40).optional(),
  active: z.boolean().optional(),
});

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;

  const parsed = Patch.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data tidak valid.");

  await connectDB();
  const item = await Contact.findByIdAndUpdate(id, { $set: parsed.data }, { new: true });
  if (!item) return bad("Kontak tidak ditemukan.", 404);
  return ok({ item });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  await connectDB();
  await Contact.findByIdAndDelete(id);
  return ok();
}
