import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Faq } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

const Patch = z.object({
  q: z.string().min(1).max(200).optional(),
  a: z.string().min(1).max(1000).optional(),
});

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  const parsed = Patch.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data tidak valid.");
  await connectDB();
  const item = await Faq.findByIdAndUpdate(id, { $set: parsed.data }, { new: true });
  if (!item) return bad("FAQ tidak ditemukan.", 404);
  return ok({ item });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  await connectDB();
  await Faq.findByIdAndDelete(id);
  return ok();
}
