import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Faq } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();
  const items = await Faq.find().sort({ order: 1 }).lean();
  return ok({ items });
}

const Body = z.object({
  q: z.string().min(1).max(200),
  a: z.string().min(1).max(1000),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Pertanyaan dan jawaban wajib diisi.");
  await connectDB();
  const max = await Faq.findOne({}, { order: 1 }).sort({ order: -1 }).lean();
  const item = await Faq.create({
    ...parsed.data,
    order: ((max as any)?.order ?? 0) + 1,
  });
  return ok({ item });
}
