import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Product } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

const Patch = z.object({
  title: z.string().min(1).max(120).optional(),
  price: z.number().min(0).max(100_000_000).optional(),
  oldPrice: z.number().min(0).max(100_000_000).optional(),
  sold: z.number().int().min(0).max(1_000_000).optional(),
  category: z.string().max(40).optional(),
  thumbnailUrl: z.string().max(500).optional(),
  audioUrl: z.string().max(500).optional(),
  badge: z.string().max(10).optional(),
  active: z.boolean().optional(),
});

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;

  const body = await req.json().catch(() => null);
  if ((body as any)?.action === "restore") {
    await connectDB();
    await Product.findByIdAndUpdate(id, { $set: { deletedAt: null } });
    return ok();
  }

  const parsed = Patch.safeParse(body);
  if (!parsed.success) return bad("Data tidak valid.");

  await connectDB();
  const item = await Product.findByIdAndUpdate(
    id,
    { $set: parsed.data },
    { new: true }
  );
  if (!item) return bad("Produk tidak ditemukan.", 404);
  return ok({ item });
}

export async function DELETE(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  const permanent = new URL(req.url).searchParams.get("permanent") === "1";

  await connectDB();
  if (permanent) {
    await Product.findByIdAndDelete(id);
  } else {
    await Product.findByIdAndUpdate(id, { $set: { deletedAt: new Date() } });
  }
  return ok();
}
