import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Product } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const url = new URL(req.url);
  const view = url.searchParams.get("view") || "all";
  const q = (url.searchParams.get("q") || "").toLowerCase();

  const filter: any =
    view === "trash"
      ? { deletedAt: { $ne: null } }
      : view === "active"
      ? { deletedAt: null, active: true }
      : { deletedAt: null };

  let items = await Product.find(filter).sort({ order: 1, createdAt: -1 }).lean();
  if (q) items = items.filter((p) => p.title.toLowerCase().includes(q));
  return ok({ items });
}

const Body = z.object({
  title: z.string().min(1).max(120),
  price: z.number().min(0).max(100_000_000),
  oldPrice: z.number().min(0).max(100_000_000).optional(),
  sold: z.number().int().min(0).max(1_000_000).optional(),
  category: z.string().max(40).optional(),
  thumbnailUrl: z.string().max(500).optional(),
  audioUrl: z.string().max(500).optional(),
  badge: z.string().max(10).optional(),
  active: z.boolean().optional(),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success)
    return bad("Data produk tidak valid: " + parsed.error.issues[0]?.message);

  await connectDB();
  const maxOrder = await Product.findOne({}, { order: 1 })
    .sort({ order: -1 })
    .lean();
  const item = await Product.create({
    ...parsed.data,
    order: ((maxOrder as any)?.order ?? 0) + 1,
  });
  return ok({ item });
}
