import { connectDB } from "@/lib/db";
import { OrderClick, Product, RequestOrder } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();

  const since = new Date(Date.now() - 13 * 864e5);
  since.setHours(0, 0, 0, 0);

  const [totalProducts, activeProducts, totalSold, requestsNew, clicks] =
    await Promise.all([
      Product.countDocuments({ deletedAt: null }),
      Product.countDocuments({ deletedAt: null, active: true }),
      Product.aggregate([
        { $match: { deletedAt: null } },
        { $group: { _id: null, total: { $sum: "$sold" } } },
      ]),
      RequestOrder.countDocuments({ status: "baru" }),
      OrderClick.find({ createdAt: { $gte: since } }).lean(),
    ]);

  const localKey = (dt: Date) =>
    `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(
      dt.getDate()
    ).padStart(2, "0")}`;

  const days: { date: string; label: string; count: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    const key = localKey(d);
    days.push({
      date: key,
      label: d.toLocaleDateString("id-ID", { day: "numeric", month: "short" }),
      count: 0,
    });
  }
  const byDay = new Map(days.map((d) => [d.date, d]));
  for (const c of clicks) {
    const key = localKey(new Date(c.createdAt));
    const row = byDay.get(key);
    if (row) row.count++;
  }

  const latestRequests = await RequestOrder.find()
    .sort({ createdAt: -1 })
    .limit(6)
    .lean();

  return ok({
    stats: {
      totalProducts,
      activeProducts,
      totalSold: totalSold[0]?.total || 0,
      clicks7d: clicks.filter(
        (c) => Date.now() - new Date(c.createdAt).getTime() < 7 * 864e5
      ).length,
      requestsNew,
    },
    chart: days,
    latestRequests,
  });
}
