import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Testimonial } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();
  const items = await Testimonial.find().sort({ order: 1 }).lean();
  return ok({ items });
}

const Body = z.object({
  name: z.string().min(1).max(60),
  message: z.string().min(1).max(500),
  rating: z.number().int().min(1).max(5).optional(),
  avatarUrl: z.string().max(500).optional(),
  show: z.boolean().optional(),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data testimoni tidak valid.");

  await connectDB();
  const max = await Testimonial.findOne({}, { order: 1 }).sort({ order: -1 }).lean();
  const item = await Testimonial.create({
    ...parsed.data,
    order: ((max as any)?.order ?? 0) + 1,
  });
  return ok({ item });
}
