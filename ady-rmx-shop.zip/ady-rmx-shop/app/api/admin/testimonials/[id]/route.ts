import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Testimonial } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

const Patch = z.object({
  name: z.string().min(1).max(60).optional(),
  message: z.string().min(1).max(500).optional(),
  rating: z.number().int().min(1).max(5).optional(),
  avatarUrl: z.string().max(500).optional(),
  show: z.boolean().optional(),
  status: z.enum(["approved", "pending"]).optional(),
});

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  const parsed = Patch.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data tidak valid.");
  await connectDB();
  const item = await Testimonial.findByIdAndUpdate(id, { $set: parsed.data }, { new: true });
  if (!item) return bad("Testimoni tidak ditemukan.", 404);
  return ok({ item });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  await connectDB();
  await Testimonial.findByIdAndDelete(id);
  return ok();
}
