import { connectDB } from "@/lib/db";
import { RequestOrder } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();
  const items = await RequestOrder.find().sort({ createdAt: -1 }).limit(300).lean();
  const baru = items.filter((i) => i.status === "baru").length;
  return ok({ items, baru });
}
