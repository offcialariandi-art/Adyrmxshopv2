import { z } from "zod";
import { connectDB } from "@/lib/db";
import { RequestOrder } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  const parsed = z
    .object({ status: z.enum(["baru", "diproses", "selesai"]) })
    .safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Status tidak valid.");
  await connectDB();
  await RequestOrder.findByIdAndUpdate(id, { $set: { status: parsed.data.status } });
  return ok();
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  const { id } = await ctx.params;
  await connectDB();
  await RequestOrder.findByIdAndDelete(id);
  return ok();
}
