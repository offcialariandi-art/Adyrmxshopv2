import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";
import { saveMedia, getDriver } from "@/lib/media";

const ALLOWED: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "audio/mpeg": ".mp3",
  "audio/ogg": ".ogg",
  "audio/wav": ".wav",
  "audio/wave": ".wav",
  "audio/x-wav": ".wav",
  "audio/aac": ".aac",
  "audio/mp4": ".m4a",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
};

const MAX_FILE = 10 * 1024 * 1024; // gambar & audio
const MAX_VIDEO = 60 * 1024 * 1024; // video (hanya driver lokal/VPS)
const MAX_DB = 12 * 1024 * 1024; // batas dokumen MongoDB

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return bad("File tidak ditemukan.");

  let ext = ALLOWED[file.type];
  if (!ext && file.name.toLowerCase().endsWith(".wav")) ext = ".wav";
  if (!ext) return bad("Tipe file tidak didukung (gambar, audio, atau video).");

  const isVideo = file.type.startsWith("video/");
  const driver = getDriver();

  // Saat menyimpan ke DB, batasi ukuran (batas dokumen MongoDB 16MB)
  const max =
    driver === "db"
      ? Math.min(MAX_DB, isVideo ? MAX_DB : MAX_FILE)
      : isVideo
      ? MAX_VIDEO
      : MAX_FILE;

  if (file.size > max)
    return bad(
      driver === "db"
        ? "Di hosting serverless (penyimpanan DB), maksimal 12MB. Untuk file besar gunakan input URL."
        : isVideo
        ? "Ukuran video maksimal 60MB."
        : "Ukuran file maksimal 10MB."
    );

  try {
    const buf = Buffer.from(await file.arrayBuffer());
    const { name, driver: used } = await saveMedia(buf, ext);
    return ok({
      url: `/api/media/${name}`,
      name,
      storage: used,
      warning:
        used === "db" && file.size > 3 * 1024 * 1024
          ? "File cukup besar tersimpan di database — pertimbangkan pakai URL eksternal untuk performa."
          : undefined,
    });
  } catch (e: any) {
    return bad(e.message || "Gagal menyimpan file.");
  }
}
