import bcrypt from "bcryptjs";
import { z } from "zod";
import { connectDB } from "@/lib/db";
import {
  Setting,
  Product,
  Contact,
  Testimonial,
  Faq,
  RequestOrder,
  OrderClick,
} from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

/** GET: export backup JSON */
export async function GET() {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  await connectDB();

  const [settings, products, contacts, testimonials, faqs, requests] =
    await Promise.all([
      Setting.findOne({ key: "main" }).lean(),
      Product.find().lean(),
      Contact.find().lean(),
      Testimonial.find().lean(),
      Faq.find().lean(),
      RequestOrder.find().lean(),
    ]);

  if (settings) (settings as any).adminHash = undefined;

  return new Response(
    JSON.stringify(
      {
        _backup: "ady-rmx-shop",
        _version: 2,
        exportedAt: new Date().toISOString(),
        settings,
        products,
        contacts,
        testimonials,
        faqs,
        requests,
      },
      null,
      2
    ),
    {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="backup-ady-rmx-${new Date()
          .toISOString()
          .slice(0, 10)}.json"`,
      },
    }
  );
}

const ImportSchema = z.object({
  settings: z.any().optional(),
  products: z.array(z.any()).optional(),
  contacts: z.array(z.any()).optional(),
  testimonials: z.array(z.any()).optional(),
  faqs: z.array(z.any()).optional(),
  requests: z.array(z.any()).optional(),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = ImportSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("File backup tidak valid.");
  const d = parsed.data;

  await connectDB();

  if (d.settings && typeof d.settings === "object") {
    const s = { ...d.settings };
    delete s._id;
    delete s.__v;
    delete s.key;
    if (!s.adminHash || typeof s.adminHash !== "string") delete s.adminHash;
    await Setting.updateOne(
      { key: "main" },
      { $set: { key: "main", ...s } },
      { upsert: true }
    );
  }

  const clean = (arr: any[], fields: string[]) =>
    arr.map((x) => {
      const o: any = {};
      for (const f of fields) if (x[f] !== undefined) o[f] = x[f];
      return o;
    });

  if (d.products) {
    await Product.deleteMany({});
    if (d.products.length)
      await Product.insertMany(
        clean(d.products, [
          "title", "price", "oldPrice", "sold", "category",
          "thumbnailUrl", "audioUrl", "badge", "active", "order", "createdAt",
        ])
      );
  }
  if (d.contacts) {
    await Contact.deleteMany({});
    if (d.contacts.length)
      await Contact.insertMany(
        clean(d.contacts, ["type", "label", "value", "active", "order"])
      );
  }
  if (d.testimonials) {
    await Testimonial.deleteMany({});
    if (d.testimonials.length)
      await Testimonial.insertMany(
        clean(d.testimonials, [
          "name", "message", "rating", "avatarUrl", "show", "order",
        ])
      );
  }
  if (d.faqs) {
    await Faq.deleteMany({});
    if (d.faqs.length) await Faq.insertMany(clean(d.faqs, ["q", "a", "order"]));
  }
  if (d.requests) {
    await RequestOrder.deleteMany({});
    if (d.requests.length)
      await RequestOrder.insertMany(
        clean(d.requests, [
          "songTitle", "category", "style", "buyerName", "note", "status", "createdAt",
        ])
      );
  }

  return ok({ message: "Backup berhasil di-restore." });
}

export async function DELETE(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);
  if (new URL(req.url).searchParams.get("confirm") !== "RESET")
    return bad("Konfirmasi reset tidak valid.");

  await connectDB();
  const doc = await Setting.findOne({ key: "main" });
  const hash = doc?.adminHash;

  await Promise.all([
    Product.deleteMany({}),
    Contact.deleteMany({}),
    Testimonial.deleteMany({}),
    Faq.deleteMany({}),
    RequestOrder.deleteMany({}),
    OrderClick.deleteMany({}),
  ]);

  if (doc) await Setting.deleteOne({ key: "main" });
  const fresh: any = { key: "main" };
  if (hash) fresh.adminHash = hash;
  else fresh.adminHash = bcrypt.hashSync("ady123", 10);
  await Setting.create(fresh);

  return ok({ message: "Data berhasil direset ke pengaturan awal." });
}
