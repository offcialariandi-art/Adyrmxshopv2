import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Product, Contact, Testimonial, Faq } from "@/models";
import { getAdminSession } from "@/lib/auth";
import { ok, bad } from "@/lib/api";

const Bulk = z.object({
  target: z.enum(["products", "contacts", "testimonials", "faqs"]),
  ids: z.array(z.string()).max(500),
});

export async function POST(req: Request) {
  const session = await getAdminSession();
  if (!session) return bad("Unauthorized", 401);

  const parsed = Bulk.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Data reorder tidak valid.");
  const { target, ids } = parsed.data;

  const Model =
    target === "products"
      ? Product
      : target === "contacts"
      ? Contact
      : target === "testimonials"
      ? Testimonial
      : Faq;

  await connectDB();
  for (let i = 0; i < ids.length; i++) {
    await Model.findByIdAndUpdate(ids[i], { $set: { order: i + 1 } });
  }
  return ok();
}
