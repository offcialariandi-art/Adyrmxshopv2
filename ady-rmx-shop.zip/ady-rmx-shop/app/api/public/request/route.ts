import { z } from "zod";
import { connectDB } from "@/lib/db";
import { RequestOrder } from "@/models";
import { ok, bad, rateLimit, clientIp } from "@/lib/api";

const Body = z.object({
  songTitle: z.string().min(1).max(150),
  category: z.string().max(60).optional(),
  style: z.string().max(60).optional(),
  buyerName: z.string().max(80).optional(),
  note: z.string().max(500).optional(),
});

export async function POST(req: Request) {
  if (!rateLimit(`req:${clientIp(req)}`, 10, 60_000))
    return bad("Terlalu sering mengirim. Tunggu sebentar.", 429);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Judul lagu wajib diisi.");

  await connectDB();
  await RequestOrder.create(parsed.data);
  return ok({ message: "Request berhasil dikirim." });
}
