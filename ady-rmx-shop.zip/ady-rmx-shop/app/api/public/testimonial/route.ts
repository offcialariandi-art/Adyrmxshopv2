import { z } from "zod";
import { connectDB } from "@/lib/db";
import { Testimonial } from "@/models";
import { ok, bad, rateLimit, clientIp } from "@/lib/api";

const Body = z.object({
  name: z.string().min(2).max(40),
  message: z.string().min(4).max(300),
  rating: z.number().int().min(1).max(5),
});

export async function POST(req: Request) {
  if (!rateLimit(`testi:${clientIp(req)}`, 3, 10 * 60_000))
    return bad("Terlalu sering mengirim. Coba lagi nanti.", 429);

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return bad("Nama, pesan, dan rating wajib diisi dengan benar.");

  await connectDB();
  await Testimonial.create({
    ...parsed.data,
    status: "pending",
    show: false,
  });

  return ok({
    message: "Terima kasih! Testimoni kamu menunggu persetujuan admin.",
  });
}
