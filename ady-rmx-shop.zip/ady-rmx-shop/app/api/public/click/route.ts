import { z } from "zod";
import { connectDB } from "@/lib/db";
import { OrderClick } from "@/models";
import { ok, rateLimit, clientIp } from "@/lib/api";

const Body = z.object({
  productTitle: z.string().max(150).optional(),
  contactType: z.string().max(20).optional(),
  contactLabel: z.string().max(40).optional(),
});

export async function POST(req: Request) {
  if (!rateLimit(`click:${clientIp(req)}`, 30, 60_000)) return ok();
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return ok();
  try {
    await connectDB();
    await OrderClick.create(parsed.data);
  } catch {}
  return ok();
}
