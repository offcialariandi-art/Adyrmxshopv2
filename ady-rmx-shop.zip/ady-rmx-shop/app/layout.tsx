import type { Metadata, Viewport } from "next";
import { Bebas_Neue, Plus_Jakarta_Sans, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { getPublicSettings } from "@/lib/settings";
import { themeVars } from "@/lib/color";

const bebas = Bebas_Neue({ weight: "400", subsets: ["latin"], variable: "--font-bebas" });
const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-jakarta",
});
const grotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-grotesk" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono2" });

export const viewport: Viewport = {
  themeColor: "#0a0c10",
  width: "device-width",
  initialScale: 1,
};

export async function generateMetadata(): Promise<Metadata> {
  try {
    const s = await getPublicSettings();
    return {
      metadataBase: new URL("https://preview.rennmodz.my.id"),
      title: `${s.storeName} — ${s.tagline}`,
      description: s.description,
      openGraph: {
        title: s.storeName,
        description: s.description,
        images: [s.bannerUrl || "/brand/banner-default.svg"],
      },
      icons: { icon: s.logoUrl || "/brand/logo-default.svg" },
    };
  } catch {
    return { title: "ADY RMX MX", description: "Toko projek sound & FLM" };
  }
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  let accent = "";
  let bg = "";
  try {
    const s = await getPublicSettings();
    accent = s.accentColor;
    bg = s.bgColor;
  } catch {}

  const themeStyle = themeVars(accent, bg) as React.CSSProperties;

  return (
    <html
      lang="id"
      style={themeStyle}
      className={`${bebas.variable} ${jakarta.variable} ${grotesk.variable} ${mono.variable}`}
    >
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
