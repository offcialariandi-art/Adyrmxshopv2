module.exports = {
  apps: [
    {
      name: "ady-rmx-shop",
      script: "node_modules/next/dist/bin/next",
      args: "start -p 8300",
      cwd: "/root/ady-rmx-shop",
      env: { PORT: "8300", NODE_ENV: "production" },
    },
  ],
};
