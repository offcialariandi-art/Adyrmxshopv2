import mongoose, { Schema, type Model } from "mongoose";

/* ---------- Setting (singleton, key='main') ---------- */
const FeatureSchema = new Schema(
  { icon: String, title: String, desc: String },
  { _id: false }
);

const SettingSchema = new Schema({
  key: { type: String, default: "main", unique: true },
  storeName: { type: String, default: "ADY RMX MX" },
  tagline: {
    type: String,
    default: "Jasa Edit Sound & Projek FLM Berkualitas",
  },
  description: {
    type: String,
    default:
      "Menjual FLM/Projek FL Studio Mobile (yang sudah jadi/request) dan menyediakan jasa remix/edit sound.",
  },
  logoUrl: { type: String, default: "" },
  bannerUrl: { type: String, default: "" },
  establishedYear: { type: Number, default: 2026 },
  announcementEnabled: { type: Boolean, default: true },
  announcementText: {
    type: String,
    default: "Selamat datang di toko kami! Order langsung via WhatsApp/Telegram.",
  },
  popupEnabled: { type: Boolean, default: false },
  popupImageUrl: { type: String, default: "" },
  popupTitle: { type: String, default: "Selamat Datang!" },
  popupSubtitle: {
    type: String,
    default: "Dapatkan projek berkualitas dengan harga terjangkau.",
  },
  popupCtaText: { type: String, default: "Lihat Produk" },
  popupCtaUrl: { type: String, default: "#produk" },
  features: {
    type: [FeatureSchema],
    default: () => [
      { icon: "headphones", title: "Kualitas Premium", desc: "Projek yang dijual berkualitas dan harganya terjangkau." },
      { icon: "lightning", title: "Proses Cepat", desc: "Akses instan ke projek yang Anda beli tanpa menunggu lama." },
      { icon: "shield", title: "Garansi Kepuasan", desc: "Order remix/req style bisa revisi jika ada yang kurang cocok." },
      { icon: "handshake", title: "Amanah & Terpercaya", desc: "Sudah lama berjualan dan memiliki banyak testimoni." },
    ],
  },
  accentColor: { type: String, default: "#e8c15a" },
  bgColor: { type: String, default: "#0a0c10" },
  requestCategories: {
    type: [String],
    default: ["FLM Full Sample", "Hanya Lagu", "Jasa Remix"],
  },
  requestStyles: {
    type: [String],
    default: ["Happy Team", "Bootleg", "Slebew", "Hipdut", "Breakbeat", "Slow", "Lainnya"],
  },
  orderTemplate: {
    type: String,
    default:
      "Halo {store}! Saya mau order:\nProduk: {produk}\nHarga: {harga}\nNama: {nama}{catatan}\n\nMohon info pembayarannya. Terima kasih!",
  },
  requestTemplate: {
    type: String,
    default:
      "Halo {store}! Saya mau request projek:\nJudul Lagu: {produk}\nKategori: {kategori}\nStyle: {style}\nNama: {nama}{catatan}\n\nMohon info selanjutnya. Terima kasih!",
  },
  // Background situs
  bgType: { type: String, enum: ["warna", "gambar", "video"], default: "warna" },
  bgMediaUrl: { type: String, default: "" },
  bgOverlay: { type: Number, default: 70 },
  // Sosial media dinamis
  socials: {
    type: [
      new Schema(
        { key: String, label: String, url: String, active: { type: Boolean, default: true } },
        { _id: false }
      ),
    ],
    default: [],
  },
  adminUser: { type: String, default: "ady" },
  adminHash: { type: String, default: "" },
});

export const Setting: Model<any> =
  mongoose.models.Setting || mongoose.model("Setting", SettingSchema);

const ProductSchema = new Schema({
  title: { type: String, required: true },
  price: { type: Number, required: true, default: 0 },
  oldPrice: { type: Number, default: 0 },
  sold: { type: Number, default: 0 },
  category: { type: String, default: "Umum" },
  thumbnailUrl: { type: String, default: "" },
  audioUrl: { type: String, default: "" },
  badge: { type: String, default: "" },
  active: { type: Boolean, default: true },
  order: { type: Number, default: 0 },
  deletedAt: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now },
});
export const Product: Model<any> =
  mongoose.models.Product || mongoose.model("Product", ProductSchema);

const ContactSchema = new Schema({
  type: { type: String, enum: ["whatsapp", "telegram"], required: true },
  label: { type: String, required: true },
  value: { type: String, required: true },
  active: { type: Boolean, default: true },
  order: { type: Number, default: 0 },
});
export const Contact: Model<any> =
  mongoose.models.Contact || mongoose.model("Contact", ContactSchema);

const TestimonialSchema = new Schema({
  name: { type: String, required: true },
  message: { type: String, required: true },
  rating: { type: Number, default: 5, min: 1, max: 5 },
  avatarUrl: { type: String, default: "" },
  show: { type: Boolean, default: true },
  status: { type: String, enum: ["approved", "pending"], default: "approved" },
  order: { type: Number, default: 0 },
});
export const Testimonial: Model<any> =
  mongoose.models.Testimonial || mongoose.model("Testimonial", TestimonialSchema);

const FaqSchema = new Schema({
  q: { type: String, required: true },
  a: { type: String, required: true },
  order: { type: Number, default: 0 },
});
export const Faq: Model<any> = mongoose.models.Faq || mongoose.model("Faq", FaqSchema);

const RequestOrderSchema = new Schema({
  songTitle: { type: String, required: true },
  category: { type: String, default: "" },
  style: { type: String, default: "" },
  buyerName: { type: String, default: "" },
  note: { type: String, default: "" },
  status: { type: String, enum: ["baru", "diproses", "selesai"], default: "baru" },
  createdAt: { type: Date, default: Date.now },
});
export const RequestOrder: Model<any> =
  mongoose.models.RequestOrder || mongoose.model("RequestOrder", RequestOrderSchema);

const OrderClickSchema = new Schema({
  productTitle: { type: String, default: "" },
  contactType: { type: String, default: "" },
  contactLabel: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now },
});
OrderClickSchema.index({ createdAt: -1 });
export const OrderClick: Model<any> =
  mongoose.models.OrderClick || mongoose.model("OrderClick", OrderClickSchema);
