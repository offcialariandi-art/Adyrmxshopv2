"use client";

import type { ComponentType } from "react";
import {
  Headphones,
  Lightning,
  ShieldCheck,
  Handshake,
  Fire,
  Diamond,
  MusicNotes,
  Star,
  Rocket,
  Crown,
  Gift,
  Percent,
  InstagramLogo,
  TiktokLogo,
  YoutubeLogo,
  FacebookLogo,
  WhatsappLogo,
  TelegramLogo,
  XLogo,
  Globe,
} from "@phosphor-icons/react";

type IconEntry = {
  label: string;
  Icon: ComponentType<{ size?: number | string; weight?: any }>;
};

export const FEATURE_ICONS: Record<string, IconEntry> = {
  headphones: { label: "Headphone", Icon: Headphones },
  music: { label: "Musik", Icon: MusicNotes },
  lightning: { label: "Cepat", Icon: Lightning },
  shield: { label: "Garansi", Icon: ShieldCheck },
  handshake: { label: "Terpercaya", Icon: Handshake },
  fire: { label: "Populer", Icon: Fire },
  star: { label: "Bintang", Icon: Star },
  diamond: { label: "Premium", Icon: Diamond },
  rocket: { label: "Rocket", Icon: Rocket },
  crown: { label: "Raja", Icon: Crown },
  gift: { label: "Bonus", Icon: Gift },
  percent: { label: "Diskon", Icon: Percent },
};

export const FEATURE_ICON_KEYS = Object.keys(FEATURE_ICONS);

export const SOCIAL_ICONS: Record<string, IconEntry> = {
  instagram: { label: "Instagram", Icon: InstagramLogo },
  tiktok: { label: "TikTok", Icon: TiktokLogo },
  youtube: { label: "YouTube", Icon: YoutubeLogo },
  facebook: { label: "Facebook", Icon: FacebookLogo },
  whatsapp: { label: "WhatsApp", Icon: WhatsappLogo },
  telegram: { label: "Telegram", Icon: TelegramLogo },
  x: { label: "X / Twitter", Icon: XLogo },
  website: { label: "Website", Icon: Globe },
};

export const SOCIAL_KEYS = Object.keys(SOCIAL_ICONS);

const LEGACY_EMOJI: Record<string, string> = {
  "🎧": "headphones",
  "🎵": "music",
  "⚡": "lightning",
  "🛡️": "shield",
  "🛡": "shield",
  "🤝": "handshake",
  "🔥": "fire",
  "💎": "diamond",
  "⭐": "star",
  "🚀": "rocket",
  "👑": "crown",
  "🎁": "gift",
  "💯": "percent",
};

export function normalizeIconKey(v?: string): string {
  const k = String(v || "").trim();
  if (FEATURE_ICONS[k]) return k;
  if (LEGACY_EMOJI[k]) return LEGACY_EMOJI[k];
  return "headphones";
}

export function FeatureIcon({
  name,
  size = 22,
  weight = "duotone",
}: {
  name?: string;
  size?: number | string;
  weight?: any;
}) {
  const entry = FEATURE_ICONS[normalizeIconKey(name)];
  const { Icon } = entry || FEATURE_ICONS.headphones;
  return <Icon size={size} weight={weight} />;
}

export function SocialIcon({
  name,
  size = 16,
  weight = "fill",
}: {
  name?: string;
  size?: number | string;
  weight?: any;
}) {
  const entry = SOCIAL_ICONS[String(name || "").trim()];
  const { Icon } = entry || SOCIAL_ICONS.website;
  return <Icon size={size} weight={weight} />;
}
