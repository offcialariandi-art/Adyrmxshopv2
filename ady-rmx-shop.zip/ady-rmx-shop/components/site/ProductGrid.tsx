"use client";

import { useMemo, useState } from "react";
import {
  MagnifyingGlass,
  ShoppingCart,
  Fire,
  Lightning,
  MusicNotes,
} from "@phosphor-icons/react";
import { useSite } from "./store";
import { PlayButton } from "./Player";
import { badgeFor, discountPercent, rupiah } from "@/lib/utils";
import type { ProductData } from "./types";

/** Gradasi placeholder deterministik dari judul produk */
const TILES = [
  "linear-gradient(135deg, #2a2140, #171a2e)",
  "linear-gradient(135deg, #402a1c, #241726)",
  "linear-gradient(135deg, #16323a, #101828)",
  "linear-gradient(135deg, #3a1630, #1d1230)",
  "linear-gradient(135deg, #143226, #0f1e2e)",
];

function PlaceholderTile({ seed }: { seed: string }) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return (
    <div
      className="relative grid h-full w-full place-items-center overflow-hidden"
      style={{ background: TILES[h % TILES.length] }}
    >
      <MusicNotes size={44} weight="duotone" className="relative text-white opacity-25" />
    </div>
  );
}

function Badge({ p }: { p: ProductData }) {
  const disc = discountPercent(p);
  const b = badgeFor(p);
  if (!b && !disc) return null;
  return (
    <div
      className="absolute left-2.5 top-2.5 z-[1] flex flex-col items-start gap-1"
      onClick={(e) => e.stopPropagation()}
    >
      {disc > 0 && (
        <span className="badge-chip bg-rose-500 text-white shadow">-{disc}%</span>
      )}
      {b === "NEW" && (
        <span className="badge-chip bg-brand text-[#14161c] shadow">
          <Lightning size={10} weight="fill" /> NEW
        </span>
      )}
      {b === "HOT" && (
        <span className="badge-chip bg-orange-500 text-white shadow">
          <Fire size={10} weight="fill" /> HOT
        </span>
      )}
      {b !== "NEW" && b !== "HOT" && b !== "" && (
        <span className="badge-chip bg-brand-dark text-white shadow">{b}</span>
      )}
    </div>
  );
}

export function ProductSection() {
  const { products, openBuy, settings, searchQuery, setSearchQuery } = useSite();
  const stickTop = settings.announcementEnabled ? "top-[100px]" : "top-16";
  const [cat, setCat] = useState("Semua");
  const [zoom, setZoom] = useState<string | null>(null);

  const categories = useMemo(
    () => ["Semua", ...Array.from(new Set(products.map((p) => p.category).filter(Boolean)))],
    [products]
  );

  const filtered = useMemo(() => {
    let list = cat === "Semua" ? products : products.filter((p) => p.category === cat);
    if (searchQuery.trim())
      list = list.filter((p) =>
        p.title.toLowerCase().includes(searchQuery.trim().toLowerCase())
      );
    return list;
  }, [products, cat, searchQuery]);

  return (
    <section id="produk" className="mx-auto w-full max-w-6xl scroll-mt-24 px-4 pb-8 pt-14">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="section-eyebrow">Katalog Lengkap</p>
          <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">
            LIST PROJEK TERSEDIA
          </h2>
        </div>
        <span className="badge-chip border border-line bg-elev text-muted">
          {products.length} produk
        </span>
      </div>

      {/* Search + filter */}
      <div
        className={`sticky z-30 -mx-4 mb-6 px-4 pb-3 pt-2 ${stickTop}`}
        style={{
          background: "var(--glass-strong)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
        }}
      >
        <div className="flex flex-col gap-2.5 sm:flex-row">
          <div className="input-wrap sm:max-w-xs">
            <MagnifyingGlass size={16} className="ml-1 shrink-0 text-dim" weight="bold" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari judul projek..."
              className="input"
            />
          </div>
          <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`shrink-0 rounded-full border px-4 py-2 text-[11px] font-bold transition ${
                  cat === c
                    ? "border-transparent bg-gradient-to-br from-brand-2 to-brand text-[#14161c] shadow-glow"
                    : "border-line bg-elev text-muted hover:text-ink"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="card mx-auto max-w-sm p-10 text-center">
          <MagnifyingGlass size={34} weight="duotone" className="mx-auto text-dim" />
          <p className="mt-3 text-sm font-bold">Tidak ada projek ditemukan</p>
          <p className="mt-1 text-xs text-dim">
            Coba kata kunci lain atau minta request custom.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3.5 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => {
            const idx = products.indexOf(p);
            return (
              <article
                key={p._id}
                className="card-premium card group relative flex h-full flex-col p-0"
              >
                <div
                  className="relative aspect-[3/4] cursor-zoom-in overflow-hidden rounded-t-[19px]"
                  onClick={() => p.thumbnailUrl && setZoom(p.thumbnailUrl)}
                >
                  {p.thumbnailUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={p.thumbnailUrl}
                      alt={p.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <PlaceholderTile seed={p.title + p._id} />
                  )}
                  <Badge p={p} />
                  {p.category && (
                    <span
                      className="badge-chip absolute right-2 top-2 z-[1] border border-line bg-k70 text-white backdrop-blur-sm"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {p.category}
                    </span>
                  )}
                  {/* Play overlay di gambar */}
                  {p.audioUrl && (
                    <div
                      className="absolute bottom-2 right-2 z-[1]"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <PlayButton index={idx} />
                    </div>
                  )}
                </div>

                <div className="flex flex-1 flex-col gap-2 p-3.5">
                  <h3 className="line-clamp-2 min-h-[2.6em] text-[13px] font-bold leading-snug">
                    {p.title}
                  </h3>

                  {/* Harga: satu baris, tidak pernah wrap */}
                  <div className="flex items-baseline gap-1.5 overflow-hidden whitespace-nowrap">
                    <span className="shrink-0 font-display text-base font-bold text-brand">
                      {rupiah(p.price)}
                    </span>
                    {!!discountPercent(p) && (
                      <span className="truncate text-[10px] font-semibold text-dim line-through">
                        {rupiah(p.oldPrice || 0)}
                      </span>
                    )}
                  </div>

                  <p className="-mt-0.5 text-[10px] font-semibold text-dim">
                    Terjual: {p.sold}
                  </p>

                  {/* Tombol selalu sejajar di dasar kartu */}
                  <div className="mt-auto pt-2">
                    <button
                      onClick={() => openBuy(p)}
                      className="btn btn-primary w-full whitespace-nowrap px-3 py-2 text-[11px]"
                    >
                      <ShoppingCart size={13} weight="bold" />
                      Beli Sekarang
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Lightbox thumbnail */}
      {zoom && (
        <div
          className="fixed inset-0 z-[85] grid cursor-zoom-out place-items-center bg-k85 p-6 anim-fade"
          onClick={() => setZoom(null)}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={zoom}
            alt="preview"
            className="anim-pop max-h-[85vh] max-w-full rounded-2xl object-contain shadow-soft-lg"
          />
        </div>
      )}
    </section>
  );
}
