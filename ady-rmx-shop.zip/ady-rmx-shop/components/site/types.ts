export interface SettingsData {
  storeName: string;
  tagline: string;
  description: string;
  logoUrl: string;
  bannerUrl: string;
  establishedYear: number;
  announcementEnabled: boolean;
  announcementText: string;
  popupEnabled: boolean;
  popupImageUrl: string;
  popupTitle: string;
  popupSubtitle: string;
  popupCtaText: string;
  popupCtaUrl: string;
  features: { icon: string; title: string; desc: string }[];
  accentColor: string;
  bgColor: string;
  bgType: string;
  bgMediaUrl: string;
  bgOverlay: number;
  socials: { key: string; label: string; url: string; active: boolean }[];
  requestCategories: string[];
  requestStyles: string[];
  orderTemplate: string;
  requestTemplate: string;
}

export interface ProductData {
  _id: string;
  title: string;
  price: number;
  oldPrice?: number;
  sold: number;
  category: string;
  thumbnailUrl?: string;
  audioUrl?: string;
  badge?: string;
  active?: boolean;
  deletedAt?: string | null;
  createdAt?: string;
}

export interface ContactData {
  _id: string;
  type: "whatsapp" | "telegram";
  label: string;
  value: string;
  active: boolean;
}

export interface TestimonialData {
  _id: string;
  name: string;
  message: string;
  rating: number;
  avatarUrl?: string;
}

export interface FaqData {
  _id: string;
  q: string;
  a: string;
}
