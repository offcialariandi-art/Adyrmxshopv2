"use client";

import { useEffect, useState } from "react";
import {
  HouseSimple,
  Package,
  NotePencil,
  WhatsappLogo,
  TelegramLogo,
} from "@phosphor-icons/react";
import { useSite } from "./store";

/* ---------- Top nav desktop ---------- */
export function TopNav() {
  const { settings, activeContacts } = useSite();
  const [solid, setSolid] = useState(false);
  useEffect(() => {
    const f = () => setSolid(window.scrollY > 30);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);

  const wa = activeContacts.find((c) => c.type === "whatsapp");
  const tg = activeContacts.find((c) => c.type === "telegram");

  return (
    <nav
      className={`transition-all duration-300 ${solid ? "glass shadow-soft" : ""}`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        {/* Kiri: logo + nama store */}
        <a href="#top" className="flex min-w-0 items-center gap-2.5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={settings.logoUrl || "/brand/logo-default.svg"}
            alt="logo"
            className="h-9 w-9 shrink-0 rounded-full border border-brand object-cover shadow-glow"
          />
          <span className="truncate font-poster text-xl tracking-wider text-ink">
            {settings.storeName.toUpperCase()}
          </span>
        </a>

        {/* Tengah: menu (desktop) */}
        <div className="hidden items-center gap-6 text-xs font-bold text-muted md:flex">
          <a href="#top" className="transition hover:text-brand">Dashboard</a>
          <a href="#produk" className="transition hover:text-brand">Produk</a>
          <a href="#request" className="transition hover:text-brand">Request</a>
        </div>

        {/* Kanan: tombol chat solid */}
        <div className="flex shrink-0 items-center gap-2.5">
          {wa && (
            <a
              href={`https://wa.me/${wa.value.replace(/[^0-9]/g, "")}`}
              target="_blank"
              rel="noreferrer"
              title={`WhatsApp ${wa.label}`}
              className="grid h-10 w-10 place-items-center rounded-full bg-emerald-500 text-white shadow-glow transition hover:-translate-y-0.5 hover:bg-emerald-400"
            >
              <WhatsappLogo size={21} weight="fill" />
            </a>
          )}
          {tg && (
            <a
              href={`https://t.me/${tg.value.replace(/^@/, "")}`}
              target="_blank"
              rel="noreferrer"
              title={`Telegram ${tg.label}`}
              className="grid h-10 w-10 place-items-center rounded-full bg-sky-500 text-white shadow-glow transition hover:-translate-y-0.5 hover:bg-sky-400"
            >
              <TelegramLogo size={21} weight="fill" />
            </a>
          )}
        </div>
      </div>
    </nav>
  );
}

/* ---------- Bottom nav mobile ---------- */
export function BottomNav() {
  const [active, setActive] = useState("#top");
  useEffect(() => {
    const ids = ["#top", "#produk", "#request"];
    const f = () => {
      let cur = "#top";
      for (const id of ids) {
        const el = document.querySelector(id);
        if (el && el.getBoundingClientRect().top <= 140) cur = id;
      }
      setActive(cur);
    };
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);

  const items = [
    { id: "#top", label: "Dashboard", Icon: HouseSimple },
    { id: "#produk", label: "Produk", Icon: Package },
    { id: "#request", label: "Request", Icon: NotePencil },
  ];

  return (
    <div className="safe-bottom fixed inset-x-0 bottom-0 z-[60] md:hidden">
      <div className="glass mx-auto flex items-stretch justify-around rounded-t-3xl px-2 pt-1.5 shadow-soft-lg">
        {items.map(({ id, label, Icon }) => {
          const on = active === id;
          return (
            <a
              key={id}
              href={id}
              className={`relative flex flex-1 flex-col items-center gap-0.5 rounded-2xl px-1 py-2 transition ${
                on ? "text-brand" : "text-dim hover:text-muted"
              }`}
            >
              {on && (
                <span className="absolute -top-1.5 h-1 w-8 rounded-full bg-gradient-to-r from-brand-2 to-brand shadow-glow" />
              )}
              <Icon size={19} weight={on ? "fill" : "regular"} />
              <span className="text-[10px] font-bold">{label}</span>
            </a>
          );
        })}
      </div>
    </div>
  );
}
