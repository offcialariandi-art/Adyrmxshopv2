"use client";

import { useEffect, useState } from "react";
import {
  Megaphone,
  Star,
  CaretDown,
  ArrowUp,
  X,
  MusicNotes,
  Fire,
  ChatCircleDots,
  ChatsCircle,
} from "@phosphor-icons/react";
import { useSite } from "./store";
import { TestimonialModal } from "./TestimonialModal";
import { FeatureIcon, SocialIcon } from "./FeatureIcon";

/* ---------- Announcement marquee ---------- */
export function AnnouncementBar() {
  const { settings } = useSite();
  if (!settings.announcementEnabled || !settings.announcementText) return null;
  return (
    <div className="relative z-40 overflow-hidden border-b border-line bg-elev py-2">
      <div className="marquee-track">
        {[0, 1].map((k) => (
          <span key={k} className="flex items-center">
            {Array(4)
              .fill(settings.announcementText)
              .map((t, i) => (
                <span
                  key={i}
                  className="flex items-center gap-1.5 pr-8 text-[11px] font-bold tracking-wide text-brand"
                >
                  <Megaphone size={13} weight="fill" />
                  {t}
                </span>
              ))}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------- Popup welcome ---------- */
export function WelcomePopup() {
  const { settings } = useSite();
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem("ady_popup_seen")) setShow(true);
    } catch {}
  }, []);

  if (!settings.popupEnabled || !show) return null;

  const close = () => {
    try {
      localStorage.setItem("ady_popup_seen", "1");
    } catch {}
    setShow(false);
  };

  return (
    <div className="fixed inset-0 z-[75] grid place-items-center bg-k75 p-5 anim-fade backdrop-blur-sm">
      <div className="card anim-pop relative w-full max-w-sm overflow-hidden p-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={settings.popupImageUrl || "/brand/banner-default.svg"}
          alt="promo"
          className="aspect-video w-full object-cover"
        />
        <div className="space-y-2 p-6 text-center">
          <h3 className="font-poster text-3xl tracking-wide text-brand">
            {settings.popupTitle}
          </h3>
          <p className="text-xs leading-relaxed text-muted">{settings.popupSubtitle}</p>
          <a
            href={settings.popupCtaUrl || "#produk"}
            onClick={close}
            className="btn btn-primary mt-3 w-full"
          >
            {settings.popupCtaText}
          </a>
        </div>
        <button
          onClick={close}
          className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-k60 text-white"
          aria-label="Tutup"
        >
          <X size={14} weight="bold" />
        </button>
      </div>
    </div>
  );
}

/* ---------- Logo ---------- */
export function BrandLogo({ size = 96 }: { size?: number }) {
  const { settings } = useSite();
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={settings.logoUrl || "/brand/logo-default.svg"}
      alt="logo"
      style={{ width: size, height: size }}
      className="rounded-full border-2 border-brand object-cover shadow-glow"
    />
  );
}

/* ---------- Stats strip ---------- */
export function StatsStrip() {
  const { products, settings } = useSite();
  const totalSold = products.reduce((a, p) => a + (p.sold || 0), 0);
  const years =
    new Date().getFullYear() - (settings.establishedYear || new Date().getFullYear());
  const items = [
    { Icon: MusicNotes, color: "text-brand", val: products.length, label: "Projek Tersedia" },
    { Icon: Fire, color: "text-orange-400", val: `${totalSold}+`, label: "Total Terjual" },
    {
      Icon: Star,
      color: "text-amber-400",
      val: years > 0 ? `${years} Thn` : "Baru",
      label: "Pengalaman",
    },
    {
      Icon: ChatCircleDots,
      color: "text-emerald-400",
      val: "Fast",
      label: "Respon Order",
    },
  ];
  return (
    <section className="mx-auto max-w-6xl px-4 py-6">
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        {items.map(({ Icon, color, val, label }, i) => (
          <div
            key={i}
            className="card card-premium anim-fade-up relative overflow-hidden p-5"
            style={{ animationDelay: `${i * 70}ms` }}
          >
            <span
              className="pointer-events-none absolute inset-x-0 top-0 h-[2px] opacity-70"
              style={{
                background:
                  "linear-gradient(to right, transparent, var(--brand), transparent)",
              }}
            />
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-poster text-4xl leading-none tracking-wide text-brand">
                  {val}
                </p>
                <p className="mt-2 truncate text-[9px] font-extrabold uppercase tracking-[0.18em] text-dim">
                  {label}
                </p>
              </div>
              <span
                className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${color}`}
                style={{ background: "var(--brand-soft)" }}
              >
                <Icon size={19} weight="duotone" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Fitur unggulan ---------- */
export function Features() {
  const { settings } = useSite();
  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-6">
        <p className="section-eyebrow">Kenapa Kami</p>
        <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">
          KEUNGGULAN TOKO
        </h2>
      </div>
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        {(settings.features || []).map((f, i) => (
          <div
            key={i}
            className="card card-premium anim-fade-up group relative overflow-hidden p-5"
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <span className="pointer-events-none absolute -right-2 -top-4 select-none font-poster text-7xl leading-none text-white opacity-5">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand-2 to-brand text-[#14161c] shadow-glow transition duration-300 group-hover:scale-110">
              <FeatureIcon name={f.icon} size={21} weight="fill" />
            </span>
            <h3 className="mt-3.5 text-sm font-bold">{f.title}</h3>
            <p className="mt-1.5 text-[11px] leading-relaxed text-muted">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Testimoni carousel ---------- */
export function Testimonials({ items }: { items: any[] }) {
  const visible = items.filter((t) => t.show !== false);
  const [showForm, setShowForm] = useState(false);
  if (!visible.length && !showForm) {
    return (
      <section className="mx-auto max-w-6xl px-4 py-14">
        <div className="card mx-auto max-w-md p-10 text-center">
          <ChatsCircle size={34} weight="duotone" className="mx-auto text-dim" />
          <p className="mt-3 text-sm font-bold">Belum ada testimoni</p>
          <p className="mt-1 text-xs text-dim">
            Jadilah yang pertama menulis pengalamanmu!
          </p>
          <button onClick={() => setShowForm(true)} className="btn btn-primary mt-5">
            Tulis Testimoni
          </button>
          {showForm && <TestimonialModal onClose={() => setShowForm(false)} />}
        </div>
      </section>
    );
  }
  if (!visible.length) {
    return showForm ? <TestimonialModal onClose={() => setShowForm(false)} /> : null;
  }
  return (
    <section className="py-14">
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="section-eyebrow">Producer Reviews</p>
            <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">KATA MEREKA</h2>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="badge-chip border border-line bg-elev text-muted">
              <Star size={11} weight="fill" className="text-brand" />
              {(visible.reduce((a, t) => a + (t.rating || 5), 0) / visible.length).toFixed(1)} / 5.0
            </span>
            <button onClick={() => setShowForm(true)} className="btn btn-dark py-3 text-xs">
              <ChatsCircle size={15} weight="bold" /> Tulis Testimoni
            </button>
          </div>
        </div>
        <div className="no-scrollbar flex snap-x snap-mandatory gap-3.5 overflow-x-auto pb-2">
          {visible.map((t) => (
            <figure key={t._id} className="card w-72 shrink-0 snap-start p-5 transition duration-300 hover:-translate-y-1 hover:border-brand">
              <div className="flex gap-0.5 text-brand">
                {Array.from({ length: t.rating || 5 }).map((_, i) => (
                  <Star key={i} size={13} weight="fill" />
                ))}
              </div>
              <blockquote className="mt-3 min-h-[60px] text-[12px] leading-relaxed text-muted">
                “{t.message}”
              </blockquote>
              <figcaption className="mt-4 flex items-center gap-2.5">
                {t.avatarUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={t.avatarUrl}
                    alt={t.name}
                    className="h-9 w-9 rounded-full object-cover"
                  />
                ) : (
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-soft font-display text-sm font-bold text-brand">
                    {t.name.charAt(0).toUpperCase()}
                  </span>
                )}
                <span className="text-xs font-bold">{t.name}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
      {showForm && <TestimonialModal onClose={() => setShowForm(false)} />}
    </section>
  );
}

/* ---------- FAQ accordion ---------- */
export function FaqAccordion({ items }: { items: any[] }) {
  const [open, setOpen] = useState<number | null>(null);
  if (!items.length) return null;
  return (
    <section className="mx-auto max-w-3xl px-4 py-14">
      <p className="section-eyebrow">Bantuan</p>
      <h2 className="mb-6 mt-2 font-poster text-4xl tracking-wide md:text-5xl">
        SERING DITANYAKAN
      </h2>
      <div className="space-y-2.5">
        {items.map((f, i) => (
          <div key={f._id} className="card overflow-hidden p-0">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
            >
              <span className="text-[13px] font-bold">{f.q}</span>
              <CaretDown
                size={16}
                weight="bold"
                className={`shrink-0 text-brand transition-transform duration-300 ${
                  open === i ? "rotate-180" : ""
                }`}
              />
            </button>
            <div
              className={`grid transition-all duration-300 ease-out ${
                open === i ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              }`}
            >
              <div className="overflow-hidden">
                <p className="whitespace-pre-line border-t border-line px-5 py-4 text-xs leading-relaxed text-muted">
                  {f.a}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- Footer ---------- */
export function Footer() {
  const { settings } = useSite();
  const activeSocials = (settings.socials || []).filter((s) => s.active && s.url);

  return (
    <footer className="mt-8 border-t border-line bg-elev">
      <div className="mx-auto max-w-6xl px-4 py-14 text-center">
        {/* Wordmark */}
        <div className="mb-5 flex items-center justify-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={settings.logoUrl || "/brand/logo-default.svg"}
            alt="logo"
            className="h-12 w-12 rounded-full border border-brand object-cover"
          />
          <p className="font-poster text-4xl tracking-wider">
            {settings.storeName.toUpperCase()}
            <span className="text-brand">.</span>
          </p>
        </div>

        <p className="mx-auto max-w-md text-xs leading-relaxed text-muted">
          {settings.description}
        </p>

        {/* Sosmed bulat */}
        <div className="mt-7 flex justify-center gap-3">
          {activeSocials.map((s) => (
            <a
              key={s.key + s.url}
              href={s.url}
              target="_blank"
              rel="noreferrer"
              title={s.label}
              aria-label={s.label}
              className="grid h-11 w-11 place-items-center rounded-full border border-line bg-card text-muted transition hover:-translate-y-1 hover:border-brand hover:text-brand hover:shadow-glow"
            >
              <SocialIcon name={s.key} size={18} />
            </a>
          ))}
          {!activeSocials.length && (
            <span className="text-xs text-dim">Belum ada sosial media.</span>
          )}
        </div>

        {/* Link cepat */}
        <div className="mt-8 flex justify-center gap-6 text-[10px] font-extrabold uppercase tracking-[0.2em] text-dim">
          <a href="#produk" className="transition hover:text-brand">Produk</a>
          <span aria-hidden>•</span>
          <a href="#request" className="transition hover:text-brand">Request</a>
          <span aria-hidden>•</span>
          <a href="#top" className="transition hover:text-brand">Atas</a>
        </div>

        <div className="mx-auto mt-8 max-w-md border-t border-line pt-6">
          <p className="text-[10px] font-semibold text-dim">
            &copy; {new Date().getFullYear()} {settings.storeName}. All rights reserved.
          </p>
          <p className="mt-1.5 text-[10px] italic text-dim opacity-70">
            Crafted with precision.
          </p>
          <a
            href="/admin"
            className="mt-3 inline-block text-[9px] font-bold uppercase tracking-widest text-dim transition hover:text-brand"
          >
            Admin Panel
          </a>
        </div>
      </div>
    </footer>
  );
}

/* ---------- Back to top ---------- */
export function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const f = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  if (!show) return null;
  return (
    <a
      href="#top"
      aria-label="Ke atas"
      className="glass fixed right-4 top-[104px] z-40 grid h-10 w-10 place-items-center rounded-full text-brand shadow-soft transition hover:-translate-y-0.5"
    >
      <ArrowUp size={17} weight="bold" />
    </a>
  );
}
