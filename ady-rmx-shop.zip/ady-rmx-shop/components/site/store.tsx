"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ContactData, ProductData, SettingsData } from "./types";
import { buildTgLink, buildWaLink, renderTemplate, rupiah } from "@/lib/utils";

export interface SheetState {
  open: boolean;
  mode: "buy" | "request";
  title: string;
  price: number;
}

interface RequestDraft {
  songTitle: string;
  category: string;
  style: string;
  buyerName: string;
  note: string;
}

interface StoreCtx {
  settings: SettingsData;
  products: ProductData[];
  contacts: ContactData[];
  activeContacts: ContactData[];
  audioList: ProductData[];
  currentTrack: number;
  playing: boolean;
  progress: number;
  duration: number;
  sheet: SheetState;
  toast: string;
  playTrack: (i: number) => void;
  togglePlay: () => void;
  seek: (t: number) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  closeSheet: () => void;
  showToast: (msg: string) => void;
  openBuy: (p: ProductData) => void;
  openRequest: () => void;
  contactLink: (c: ContactData) => Promise<void>;
  setBuyer: (b: { nama?: string; catatan?: string }) => void;
  setRequestDraft: (d: Partial<RequestDraft>) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const Ctx = createContext<StoreCtx | null>(null);
export const useSite = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSite harus di dalam SiteProvider");
  return v;
};

export function SiteProvider({
  data,
  children,
}: {
  data: {
    settings: SettingsData;
    products: ProductData[];
    contacts: ContactData[];
    testimonials: any[];
    faqs: any[];
  };
  children: React.ReactNode;
}) {
  const { settings, products, contacts } = data;

  const activeContacts = useMemo(() => contacts.filter((c) => c.active), [contacts]);
  const audioList = useMemo(() => products.filter((p) => p.audioUrl), [products]);

  const [currentTrack, setCurrent] = useState(-1);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [sheet, setSheet] = useState<SheetState>({
    open: false,
    mode: "buy",
    title: "",
    price: 0,
  });
  const [toastMsg, setToastMsg] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const buyerRef = useRef<{ nama?: string; catatan?: string }>({});
  const requestRef = useRef<RequestDraft>({
    songTitle: "",
    category: "",
    style: "",
    buyerName: "",
    note: "",
  });
  const sheetRef = useRef<SheetState>(sheet);
  sheetRef.current = sheet;

  useEffect(() => {
    if (!audioRef.current) return;
    if (currentTrack >= 0 && audioList[currentTrack]?.audioUrl) {
      audioRef.current.src = audioList[currentTrack].audioUrl!;
      audioRef.current
        .play()
        .then(() => setPlaying(true))
        .catch(() => setPlaying(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentTrack]);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(""), 2600);
    return () => clearTimeout(t);
  }, [toastMsg]);

  const playTrack = useCallback(
    (i: number) => {
      if (i === currentTrack && playing) {
        audioRef.current?.pause();
        setPlaying(false);
        return;
      }
      if (i === currentTrack && audioRef.current) {
        audioRef.current.play();
        setPlaying(true);
        return;
      }
      setCurrent(i);
    },
    [currentTrack, playing]
  );

  const togglePlay = useCallback(() => {
    const el = audioRef.current;
    if (!el || currentTrack < 0) return;
    if (playing) {
      el.pause();
      setPlaying(false);
    } else {
      el.play();
      setPlaying(true);
    }
  }, [playing, currentTrack]);

  const seek = useCallback((t: number) => {
    if (audioRef.current) audioRef.current.currentTime = t;
  }, []);

  const nextTrack = useCallback(
    () => audioList.length && setCurrent((c) => (c + 1) % audioList.length),
    [audioList.length]
  );
  const prevTrack = useCallback(
    () =>
      audioList.length &&
      setCurrent((c) => (c - 1 + audioList.length) % audioList.length),
    [audioList.length]
  );

  const showToast = useCallback((m: string) => setToastMsg(m), []);
  const closeSheet = useCallback(() => setSheet((s) => ({ ...s, open: false })), []);

  const logClick = useCallback((c: ContactData, title: string) => {
    fetch("/api/public/click", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productTitle: title,
        contactType: c.type,
        contactLabel: c.label,
      }),
    }).catch(() => {});
  }, []);

  /** Klik kontak di sheet — buy atau request */
  const contactLink = useCallback(
    async (c: ContactData) => {
      const s = sheetRef.current;
      let msg = "";
      let logTitle = "";

      if (s.mode === "buy") {
        msg = renderTemplate(settings.orderTemplate, {
          store: settings.storeName,
          produk: s.title,
          harga: rupiah(s.price),
          ...(buyerRef.current as any),
        });
        logTitle = s.title;
      } else {
        const d = requestRef.current;
        if (!d.songTitle.trim()) {
          showToast("Judul lagu wajib diisi dulu ya!");
          return;
        }
        try {
          const res = await fetch("/api/public/request", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              songTitle: d.songTitle,
              category: d.category,
              style: d.style,
              buyerName: d.buyerName,
              note: d.note,
            }),
          });
          const j = await res.json();
          if (!j.ok) throw new Error(j.error);
        } catch (e: any) {
          showToast(e.message || "Gagal menyimpan request.");
          return;
        }
        msg = renderTemplate(settings.requestTemplate, {
          store: settings.storeName,
          produk: d.songTitle,
          kategori: d.category || "-",
          style: d.style || "-",
          nama: d.buyerName,
          catatan: d.note,
        });
        logTitle = "Request Projek";
      }

      const url =
        c.type === "whatsapp" ? buildWaLink(c.value, msg) : buildTgLink(c.value);
      logClick(c, logTitle);
      window.open(url, "_blank");
      closeSheet();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [settings.orderTemplate, settings.requestTemplate, settings.storeName, logClick, closeSheet]
  );

  const openBuy = useCallback(
    (p: ProductData) => {
      if (!activeContacts.length) {
        showToast("Kontak order belum diatur oleh admin.");
        return;
      }
      if (activeContacts.length === 1) {
        const c = activeContacts[0];
        const msg = renderTemplate(settings.orderTemplate, {
          store: settings.storeName,
          produk: p.title,
          harga: rupiah(p.price),
          nama: "",
          catatan: "",
        });
        const url =
          c.type === "whatsapp" ? buildWaLink(c.value, msg) : buildTgLink(c.value);
        logClick(c, p.title);
        window.open(url, "_blank");
        return;
      }
      setSheet({ open: true, mode: "buy", title: p.title, price: p.price });
    },
    [activeContacts, settings.orderTemplate, settings.storeName, logClick, showToast]
  );

  const openRequest = useCallback(() => {
    if (!activeContacts.length) {
      showToast("Kontak order belum diatur oleh admin.");
      return;
    }
    setSheet({ open: true, mode: "request", title: "Request Projek", price: 0 });
  }, [activeContacts, showToast]);

  const value: StoreCtx = {
    settings,
    products,
    contacts,
    activeContacts,
    audioList,
    currentTrack,
    playing,
    progress,
    duration,
    sheet,
    toast: toastMsg,
    playTrack,
    togglePlay,
    seek,
    nextTrack,
    prevTrack,
    closeSheet,
    showToast,
    openBuy,
    openRequest,
    contactLink,
    setBuyer: (b) => {
      buyerRef.current = { ...buyerRef.current, ...b };
    },
    setRequestDraft: (d) => {
      requestRef.current = { ...requestRef.current, ...d };
    },
    searchQuery,
    setSearchQuery,
  };

  return (
    <Ctx.Provider value={value}>
      <audio
        ref={audioRef}
        onTimeUpdate={(e) => {
          const el = e.currentTarget;
          setProgress(el.currentTime);
          setDuration(el.duration || 0);
        }}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
        onEnded={nextTrack}
        preload="none"
      />
      {children}
      {toastMsg && (
        <div className="fixed left-1/2 top-[104px] z-[90] -translate-x-1/2 anim-fade">
          <div className="glass rounded-2xl px-5 py-3 text-[13px] font-bold shadow-soft-lg border border-brand text-brand">
            {toastMsg}
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}
