"use client";

import { SiteProvider, useSite } from "./store";
import type {
  ContactData,
  FaqData,
  ProductData,
  SettingsData,
  TestimonialData,
} from "./types";
import {
  WelcomePopup,
  AnnouncementBar,
  StatsStrip,
  Features,
  Testimonials,
  FaqAccordion,
  Footer,
  BackToTop,
} from "./sections";
import { Hero } from "./Hero";
import { TopNav, BottomNav } from "./NavBars";
import { ProductCarousel } from "./ProductCarousel";
import { MixShowcase } from "./MixShowcase";
import { TrendingList } from "./TrendingList";
import { ProductSection } from "./ProductGrid";
import { RequestSection } from "./RequestForm";
import { MiniPlayer } from "./Player";
import { BuySheet } from "./BuySheet";

/** Layer background gambar/video dari admin */
function BgLayer() {
  const { settings } = useSite();
  if (!settings.bgMediaUrl || settings.bgType === "warna") return null;
  const overlay = Math.min(90, Math.max(0, settings.bgOverlay ?? 70)) / 100;
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {settings.bgType === "video" ? (
        <video
          src={settings.bgMediaUrl}
          autoPlay
          muted
          loop
          playsInline
          className="h-full w-full object-cover"
        />
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={settings.bgMediaUrl}
          alt=""
          className="h-full w-full object-cover"
        />
      )}
      <div className="absolute inset-0" style={{ background: `rgba(8,10,14,${overlay})` }} />
    </div>
  );
}

/** Header tetap: marquee paling depan + navbar di bawahnya */
function HeaderStack() {
  const { settings } = useSite();
  const ann = !!settings.announcementEnabled && !!settings.announcementText;
  return (
    <div className="fixed inset-x-0 top-0 z-[70]">
      {ann && <AnnouncementBar />}
      <TopNav />
    </div>
  );
}


export function SiteApp({
  settings,
  products,
  contacts,
  testimonials,
  faqs,
}: {
  settings: SettingsData;
  products: ProductData[];
  contacts: ContactData[];
  testimonials: TestimonialData[];
  faqs: FaqData[];
}) {
  return (
    <SiteProvider data={{ settings, products, contacts, testimonials, faqs }}>
      <BgLayer />

      <div className="relative z-10">
        <HeaderStack />
        <main style={{ paddingTop: settings.announcementEnabled ? 96 : 64 }}>
          <Hero />
          <ProductCarousel />
          <MixShowcase />
          <StatsStrip />
          <Features />
          <ProductSection />
          <TrendingList />
          <Testimonials items={testimonials} />
          <RequestSection />
          <FaqAccordion items={faqs} />
        </main>
        <Footer />
        {/* Ruang aman agar konten tidak tertutup bottom-nav + player */}
        <div aria-hidden className="h-[130px] md:h-[84px]" />
      </div>

      <BackToTop />
      <MiniPlayer />
      <BottomNav />
      <BuySheet />
      <WelcomePopup />
    </SiteProvider>
  );
}
