"use client";

import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
} from "@phosphor-icons/react";
import { useSite } from "./store";

const fmt = (t: number) => {
  if (!t || !isFinite(t)) return "0:00";
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

export function MiniPlayer() {
  const {
    settings,
    audioList,
    currentTrack,
    playing,
    progress,
    duration,
    playTrack,
    togglePlay,
    seek,
    nextTrack,
    prevTrack,
  } = useSite();

  const track = currentTrack >= 0 ? audioList[currentTrack] : null;
  if (!track) return null;

  const pct = duration ? (progress / duration) * 100 : 0;
  const art = track.thumbnailUrl || settings.logoUrl || "/brand/logo-default.svg";

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(76px+env(safe-area-inset-bottom))] z-[70] flex justify-center px-3 md:bottom-4 md:justify-end md:pr-6">
      <div
        className="anim-pop pointer-events-auto w-full max-w-md rounded-[20px] border border-line p-3 shadow-soft-lg"
        style={{ background: "var(--glass-strong)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)" }}
      >
        <div className="flex items-center gap-3">
          {/* Disc art */}
          <div className="relative h-12 w-12 shrink-0">
            <div
              className={`h-full w-full overflow-hidden rounded-full border border-brand shadow-glow ${
                playing ? "disc-spin" : ""
              }`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={art} alt="" className="h-full w-full object-cover" />
            </div>
            <span className="absolute inset-0 m-auto h-3 w-3 rounded-full border border-brand bg-[#14161c]" />
          </div>

          <div className="min-w-0 flex-1">
            <p className="truncate text-[12px] font-bold">{track.title}</p>
            <p className="font-mono text-[9px] text-dim">
              {fmt(progress)} / {fmt(duration)}
              {playing && (
                <span className="ml-2 inline-flex h-2.5 items-end gap-[2px] text-brand">
                  <i className="eq-bar h-2.5" />
                  <i className="eq-bar h-2.5" />
                  <i className="eq-bar h-2.5" />
                </span>
              )}
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-1">
            <button
              onClick={prevTrack}
              className="grid h-8 w-8 place-items-center rounded-full text-muted hover:text-ink"
              aria-label="Sebelumnya"
            >
              <SkipBack size={15} weight="fill" />
            </button>
            <button
              onClick={() => playTrack(currentTrack)}
              className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-2 to-brand text-[#14161c] shadow-glow"
              aria-label={playing ? "Pause" : "Play"}
            >
              {playing ? (
                <Pause size={17} weight="fill" />
              ) : (
                <Play size={17} weight="fill" />
              )}
            </button>
            <button
              onClick={nextTrack}
              className="grid h-8 w-8 place-items-center rounded-full text-muted hover:text-ink"
              aria-label="Selanjutnya"
            >
              <SkipForward size={15} weight="fill" />
            </button>
          </div>
        </div>

        {/* Seek tipis full-width */}
        <input
          type="range"
          className="seek mt-2.5 w-full"
          min={0}
          max={duration || 0}
          step={0.5}
          value={progress}
          onChange={(e) => seek(Number(e.target.value))}
          style={{
            background: `linear-gradient(to right, var(--brand) ${pct}%, var(--line-strong) ${pct}%)`,
          }}
        />
      </div>
    </div>
  );
}

/** Tombol play bulat di kartu produk */
export function PlayButton({ index }: { index: number }) {
  const { audioList, currentTrack, playing, playTrack } = useSite();
  const hasAudio = !!audioList[index]?.audioUrl;
  const isCurrent = currentTrack === index && audioList[currentTrack];
  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        if (hasAudio) playTrack(index);
      }}
      disabled={!hasAudio}
      className={`grid h-9 w-9 shrink-0 place-items-center rounded-full transition ${
        !hasAudio
          ? "cursor-not-allowed bg-w05 text-dim opacity-50"
          : isCurrent && playing
          ? "bg-gradient-to-br from-brand-2 to-brand text-[#14161c] shadow-glow"
          : "border border-line bg-elev text-brand hover:border-brand hover:-translate-y-0.5"
      }`}
      aria-label="Putar sample"
    >
      {isCurrent && playing ? (
        <Pause size={14} weight="fill" />
      ) : (
        <Play size={14} weight="fill" />
      )}
    </button>
  );
}
