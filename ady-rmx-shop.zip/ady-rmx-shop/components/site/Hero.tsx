"use client";

import { CaretDown, MagnifyingGlass, NotePencil, Package } from "@phosphor-icons/react";
import { useSite } from "./store";
import { BrandLogo } from "./sections";

export function Hero() {
  const { settings, products, searchQuery, setSearchQuery } = useSite();

  const goSearch = () => {
    document.querySelector("#produk")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative overflow-hidden pb-10">
      {/* Blob glow */}
      <div
        className="hero-blob blob-a h-[420px] w-[420px] -top-32 -left-24"
        style={{ background: "var(--glow)" }}
      />
      <div
        className="hero-blob blob-b h-[360px] w-[360px] top-10 -right-28 opacity-70"
        style={{ background: "var(--glow-soft)", filter: "blur(110px)" }}
      />
      <div className="hero-grid absolute inset-0" />

      <div className="relative mx-auto max-w-4xl px-4 pt-10 text-center md:pt-14">
        {/* Eyebrow badge */}
        <div className="anim-fade-up mb-6 inline-flex items-center gap-2.5 rounded-full border border-line bg-card px-4 py-2">
          <span className="pulse-dot h-2 w-2 rounded-full bg-emerald-400" />
          <span className="text-[10px] font-extrabold tracking-[0.22em] text-muted">
            PREMIUM FLM MARKETPLACE
          </span>
          <span className="h-3 w-px bg-line-strong" />
          <span className="text-[10px] font-extrabold tracking-[0.22em] text-brand">
            EST. {settings.establishedYear}
          </span>
        </div>

        {/* Judul raksasa */}
        <h1 className="anim-fade-up font-poster leading-[0.98] tracking-tight" style={{ animationDelay: "80ms" }}>
          <span className="block text-[clamp(38px,10.5vw,88px)] text-ink">PROJEK SOUND</span>
          <span className="block bg-gradient-to-r from-brand-2 via-brand to-brand-2 bg-clip-text text-[clamp(38px,10.5vw,88px)] text-transparent">
            KELAS PREMIUM.
          </span>
        </h1>

        <p className="anim-fade-up mx-auto mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base" style={{ animationDelay: "160ms" }}>
          {settings.tagline} — legally crafted, high-fidelity project files untuk
          produksi musikmu.
        </p>

        {/* Search bar */}
        <div className="anim-fade-up mx-auto mt-8 max-w-xl" style={{ animationDelay: "240ms" }}>
          <div className="glass flex items-center gap-2 rounded-full p-1.5 pl-4 shadow-soft">
            <MagnifyingGlass size={18} weight="bold" className="shrink-0 text-dim" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && goSearch()}
              placeholder="Cari track, style, atau genre..."
              className="input py-3"
            />
            <button onClick={goSearch} className="btn btn-primary shrink-0 rounded-full px-5 py-2.5 text-xs">
              Cari
            </button>
          </div>
        </div>

        {/* CTA */}
        <div className="anim-fade-up mt-6 flex flex-wrap items-center justify-center gap-3" style={{ animationDelay: "320ms" }}>
          <a href="#produk" className="btn btn-primary px-7">
            <Package size={16} weight="bold" />
            Explore Produk ({products.length})
            <CaretDown size={13} weight="bold" />
          </a>
          <a href="#request" className="btn btn-dark px-7">
            <NotePencil size={16} weight="bold" />
            Request Custom
          </a>
        </div>

        {/* Banner media card + logo mengambang */}
        <div className="anim-fade-up relative mx-auto mt-10 max-w-5xl" style={{ animationDelay: "400ms" }}>
          <div className="card relative overflow-hidden p-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={settings.bannerUrl || "/brand/banner-default.svg"}
              alt={settings.storeName}
              className="aspect-video max-h-[340px] w-full object-cover md:max-h-[380px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-k60 via-transparent to-transparent" />
            <div className="absolute inset-x-4 bottom-4 flex items-center gap-3">
              <div className="shrink-0">
                <BrandLogo size={48} />
              </div>
              <div className="min-w-0 text-left">
                <p className="truncate font-poster text-xl tracking-wider text-white drop-shadow sm:text-2xl">
                  {settings.storeName.toUpperCase()}
                </p>
                <p className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400">
                  <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  ONLINE — SIAP ORDER
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
