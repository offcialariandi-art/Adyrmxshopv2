"use client";

import { Pause, Play } from "@phosphor-icons/react";
import { useSite } from "./store";

/** Showcase kreatif: Artist + Track = Mix (gaya marketplace premium) */
export function MixShowcase() {
  const { products, settings, audioList, currentTrack, playing, playTrack } = useSite();
  const demo = audioList[0];
  if (!demo) return null;

  const demoIdx = audioList.indexOf(demo);
  const isPlaying = currentTrack === demoIdx && playing;

  return (
    <section className="px-4 py-10">
      <div className="mx-auto max-w-5xl">
        <p className="section-eyebrow mb-2 text-center justify-center">Demo Sound</p>
        <h2 className="mb-6 text-center font-poster text-4xl tracking-wide md:text-5xl">
          DENGAR BEDANYA.
        </h2>

        <div
          className="grid grid-cols-2 items-center gap-3 rounded-[40px] border border-line bg-w03 p-3 md:flex md:gap-4 md:p-4"
          style={{ borderColor: "var(--glow)" }}
        >
          {/* Kartu artist */}
          <div className="relative hidden aspect-square h-full overflow-hidden rounded-[32px] md:block">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={demo.thumbnailUrl || "/brand/banner-default.svg"}
              alt={settings.storeName}
              className="h-full w-full object-cover"
            />
            <p className="absolute left-0 top-0 p-3 text-lg font-light text-white drop-shadow">
              {settings.storeName}
            </p>
          </div>

          <span className="hidden text-center font-display text-4xl font-bold text-brand md:block">
            +
          </span>

          {/* Panel judul */}
          <div className="col-span-2 flex h-full flex-col justify-between gap-2 rounded-[32px] bg-elev p-4 md:col-span-1 md:h-auto">
            <p className="text-base font-bold leading-snug md:text-xl">{demo.title}</p>
            <p className="line-clamp-3 text-[11px] leading-relaxed text-muted md:text-xs">
              {settings.description}
            </p>
            <div className="flex items-center gap-2 pt-1">
              <span className="badge-chip bg-brand-soft text-brand">FULL SAMPLE</span>
              <span className="badge-chip border border-line text-muted">
                {demo.category}
              </span>
            </div>
          </div>

          <span className="hidden text-center font-display text-4xl font-bold text-brand md:block">
            =
          </span>

          {/* Kartu mix — brand gradient */}
          <button
            onClick={() => playTrack(demoIdx)}
            className="group relative col-span-1 flex aspect-square flex-col items-center justify-between overflow-hidden rounded-[24px] p-2.5 text-left transition hover:-translate-y-1"
            style={{ background: "linear-gradient(135deg, var(--brand-2), var(--brand))" }}
          >
            <div className="flex w-full items-center justify-between text-[9px] font-extrabold tracking-widest text-[#14161c]">
              <span>MIX</span>
              <span>REMIX</span>
            </div>
            <div className="grid h-[58%] w-[58%] place-items-center overflow-hidden rounded-full border-2 border-k50 bg-k70">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={demo.thumbnailUrl || "/brand/logo-default.svg"}
                alt=""
                className={`h-full w-full object-cover ${isPlaying ? "disc-spin" : ""}`}
              />
            </div>
            <span className="line-clamp-1 w-full truncate text-center text-[12px] font-extrabold text-[#14161c]">
              {demo.title}
            </span>
            <span className="absolute inset-0 grid place-items-center rounded-[24px] bg-k50 transition group-hover:bg-transparent">
              <span className="grid h-12 w-12 place-items-center rounded-full border border-w25 bg-k50 text-white backdrop-blur-sm">
                {isPlaying ? <Pause size={18} weight="fill" /> : <Play size={18} weight="fill" />}
              </span>
            </span>
          </button>

          {/* Kartu remix gelap */}
          <button
            onClick={() => playTrack(demoIdx)}
            className="group relative col-span-1 flex aspect-square flex-col items-center justify-between overflow-hidden rounded-[24px] border border-line bg-card p-2.5 text-left transition hover:-translate-y-1 hover:border-brand"
          >
            <div className="flex w-full items-center justify-between text-[9px] font-extrabold tracking-widest text-dim">
              <span>MIX</span>
              <span>REMIX</span>
            </div>
            <div className="grid h-[58%] w-[58%] place-items-center overflow-hidden rounded-full border border-line">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/brand/logo-default.svg"
                alt=""
                className="h-full w-full object-cover"
              />
            </div>
            <span className="line-clamp-1 w-full truncate text-center text-[12px] font-extrabold text-brand">
              {settings.storeName.split(" ")[0].toUpperCase()} MIX
            </span>
            <span className="absolute inset-0 grid place-items-center rounded-[24px] bg-k60 transition group-hover:bg-transparent">
              <span className="grid h-12 w-12 place-items-center rounded-full border border-w25 bg-k70 text-white backdrop-blur-sm">
                {isPlaying ? <Pause size={18} weight="fill" /> : <Play size={18} weight="fill" />}
              </span>
            </span>
          </button>
        </div>

        <p className="mt-4 text-center text-[11px] font-semibold text-dim">
          Tekan kartu untuk memutar sample demo
        </p>
      </div>
    </section>
  );
}
