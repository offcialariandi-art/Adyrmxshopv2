"use client";

import { useState } from "react";
import { Star, X, PaperPlaneTilt } from "@phosphor-icons/react";
import { useSite } from "./store";

export function TestimonialModal({
  onClose,
}: {
  onClose: () => void;
}) {
  const { showToast } = useSite();
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(5);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (name.trim().length < 2) return setErr("Nama minimal 2 karakter.");
    if (message.trim().length < 4) return setErr("Tulis pesan testimoni dulu ya.");
    setLoading(true);
    try {
      const res = await fetch("/api/public/testimonial", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, message, rating }),
      });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error);
      onClose();
      showToast("Terima kasih! Testimoni menunggu persetujuan admin.");
    } catch (e: any) {
      setErr(e.message || "Gagal mengirim testimoni.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[95] grid place-items-center overflow-y-auto bg-k70 p-4 anim-fade backdrop-blur-sm">
      <form onSubmit={submit} className="card anim-pop my-8 w-full max-w-md p-6">
        <div className="mb-5 flex items-center justify-between">
          <h3 className="font-display text-lg font-bold">Tulis Testimoni</h3>
          <button
            type="button"
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:text-ink"
            aria-label="Tutup"
          >
            <X size={13} weight="bold" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="label">Nama *</label>
            <div className="input-wrap">
              <input
                className="input"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nama kamu"
                maxLength={40}
              />
            </div>
          </div>

          <div>
            <label className="label">Rating</label>
            <div className="flex gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  className={`text-2xl transition ${
                    n <= rating ? "text-brand" : "text-dim opacity-40"
                  }`}
                  aria-label={`${n} bintang`}
                >
                  <Star size={26} weight={n <= rating ? "fill" : "regular"} />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="label">Pesan Testimoni *</label>
            <div className="input-wrap items-start py-2">
              <textarea
                rows={3}
                className="input resize-none"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Bagaimana pengalamanmu order di sini?"
                maxLength={300}
              />
            </div>
          </div>

          {err && (
            <p className="rounded-xl border border-rose-400 bg-danger-soft px-3 py-2 text-xs font-bold text-rose-400">
              {err}
            </p>
          )}

          <button type="submit" disabled={loading} className="btn btn-primary w-full">
            <PaperPlaneTilt size={15} weight="bold" />
            {loading ? "Mengirim..." : "Kirim Testimoni"}
          </button>

          <p className="text-center text-[10px] leading-relaxed text-dim">
            Testimoni akan tampil setelah disetujui admin.
          </p>
        </div>
      </form>
    </div>
  );
}
