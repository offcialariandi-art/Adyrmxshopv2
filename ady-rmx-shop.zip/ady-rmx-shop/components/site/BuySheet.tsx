"use client";

import { useEffect, useState } from "react";
import {
  X,
  WhatsappLogo,
  TelegramLogo,
  MusicNotes,
  User,
  ChatText,
} from "@phosphor-icons/react";
import { useSite } from "./store";

export function BuySheet() {
  const {
    sheet,
    closeSheet,
    activeContacts,
    contactLink,
    setBuyer,
    setRequestDraft,
    settings,
    showToast,
  } = useSite();
  const [nama, setNama] = useState("");
  const [catatan, setCatatan] = useState("");
  // draft request
  const [songTitle, setSongTitle] = useState("");
  const [category, setCategory] = useState("");
  const [style, setStyle] = useState("");
  const [rNama, setRNama] = useState("");
  const [rNote, setRNote] = useState("");
  const isRequest = sheet.mode === "request";
  const [sending, setSending] = useState(false);

  useEffect(() => {
    document.body.style.overflow = sheet.open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [sheet.open]);

  if (!sheet.open) return null;

  const waList = activeContacts.filter((c) => c.type === "whatsapp");
  const tgList = activeContacts.filter((c) => c.type === "telegram");

  const pick = async (c: (typeof activeContacts)[number]) => {
    if (!isRequest) {
      setBuyer({ nama, catatan });
      setTimeout(() => contactLink(c), 0);
      return;
    }
    if (!songTitle.trim()) {
      showToast("Judul lagu wajib diisi dulu ya!");
      return;
    }
    setSending(true);
    setRequestDraft({
      songTitle,
      category,
      style,
      buyerName: rNama,
      note: rNote,
    });
    setTimeout(() => contactLink(c).finally(() => setSending(false)), 0);
  };

  return (
    <div className="fixed inset-0 z-[80]">
      <div
        className="absolute inset-0 bg-k70 backdrop-blur-sm anim-fade"
        onClick={closeSheet}
      />
      <div className="sheet-panel absolute bottom-0 left-0 right-0 mx-auto max-w-lg">
        <div
          className="safe-bottom max-h-[92dvh] overflow-y-auto rounded-t-[24px] border border-b-0 border-line px-5 pt-3 pb-5 shadow-soft-lg"
          style={{ background: "var(--glass-strong)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)" }}
        >
          <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-w25" />

          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-xl font-bold tracking-tight">
                {isRequest ? "Request Projek" : "Pilih Metode Order"}
              </h3>
              <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted">
                <MusicNotes size={13} weight="bold" className="text-brand" />
                {isRequest ? (
                  "Isi detail, lalu pilih metode kirim"
                ) : (
                  <>
                    {sheet.title}
                    {sheet.price > 0 && (
                      <span className="font-bold text-brand">· harga di chat</span>
                    )}
                  </>
                )}
              </p>
            </div>
            <button
              onClick={closeSheet}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line text-muted hover:text-ink"
              aria-label="Tutup"
            >
              <X size={16} weight="bold" />
            </button>
          </div>

          {/* Form order */}
          {!isRequest && (
            <div className="mb-4 space-y-2.5">
              <div className="input-wrap rounded-[14px]">
                <User size={15} weight="bold" className="ml-1 shrink-0 text-dim" />
                <input
                  className="input"
                  placeholder="Nama kamu (opsional)"
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  maxLength={60}
                />
              </div>
              <div className="input-wrap items-start py-2">
                <ChatText size={15} weight="bold" className="ml-1 mr-1 shrink-0 text-dim" />
                <textarea
                  className="input resize-none"
                  rows={2}
                  placeholder="Catatan / style yang diinginkan (opsional)"
                  value={catatan}
                  onChange={(e) => setCatatan(e.target.value)}
                  maxLength={300}
                />
              </div>
            </div>
          )}

          {/* Form request */}
          {isRequest && (
            <div className="mb-4 space-y-2.5">
              <div className="input-wrap rounded-[14px]">
                <MusicNotes size={15} weight="bold" className="ml-1 shrink-0 text-dim" />
                <input
                  className="input"
                  placeholder="Judul lagu * (wajib)"
                  value={songTitle}
                  onChange={(e) => setSongTitle(e.target.value)}
                  maxLength={150}
                />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <select
                  className="input-wrap appearance-none"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="">Kategori</option>
                  {settings.requestCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <select
                  className="input-wrap appearance-none"
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                >
                  <option value="">Style</option>
                  {settings.requestStyles.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div className="input-wrap rounded-[14px]">
                <User size={15} weight="bold" className="ml-1 shrink-0 text-dim" />
                <input
                  className="input"
                  placeholder="Nama kamu (opsional)"
                  value={rNama}
                  onChange={(e) => setRNama(e.target.value)}
                  maxLength={60}
                />
              </div>
              <div className="input-wrap items-start py-2">
                <ChatText size={15} weight="bold" className="ml-1 mr-1 shrink-0 text-dim" />
                <textarea
                  className="input resize-none"
                  rows={2}
                  placeholder="Catatan tambahan (opsional)"
                  value={rNote}
                  onChange={(e) => setRNote(e.target.value)}
                  maxLength={300}
                />
              </div>
            </div>
          )}

          {/* Daftar kontak */}
          <div className="space-y-4">
            {waList.length > 0 && (
              <div>
                <p className="label mb-2 flex items-center gap-1.5 text-emerald-400">
                  <WhatsappLogo size={14} weight="fill" /> WhatsApp
                </p>
                <div className="space-y-2">
                  {waList.map((c) => (
                    <button
                      key={c._id}
                      disabled={sending}
                      onClick={() => pick(c)}
                      className="flex w-full items-center gap-3 rounded-2xl border border-line bg-elev px-4 py-3 text-left transition hover:-translate-y-0.5 hover:border-emerald-400 disabled:opacity-50"
                    >
                      <span className="grid h-10 w-10 place-items-center rounded-full bg-ok-soft text-emerald-400">
                        <WhatsappLogo size={20} weight="fill" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-bold">{c.label}</span>
                        <span className="block truncate text-[11px] text-dim">
                          +{c.value.replace(/[^0-9]/g, "")}
                        </span>
                      </span>
                      <span className="badge-chip bg-ok-soft text-emerald-400">Chat</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {tgList.length > 0 && (
              <div>
                <p className="label mb-2 flex items-center gap-1.5 text-sky-400">
                  <TelegramLogo size={14} weight="fill" /> Telegram
                </p>
                <div className="space-y-2">
                  {tgList.map((c) => (
                    <button
                      key={c._id}
                      disabled={sending}
                      onClick={() => pick(c)}
                      className="flex w-full items-center gap-3 rounded-2xl border border-line bg-elev px-4 py-3 text-left transition hover:-translate-y-0.5 hover:border-sky-400 disabled:opacity-50"
                    >
                      <span className="grid h-10 w-10 place-items-center rounded-full bg-info-soft text-sky-400">
                        <TelegramLogo size={20} weight="fill" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px] font-bold">{c.label}</span>
                        <span className="block truncate text-[11px] text-dim">
                          @{c.value.replace(/^@/, "")}
                        </span>
                      </span>
                      <span className="badge-chip bg-info-soft text-sky-400">Chat</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <p className="mt-4 text-center text-[10px] text-dim">
            Kamu akan diarahkan ke aplikasi untuk menyelesaikan{" "}
            {isRequest ? "request" : "order"}.
          </p>
        </div>
      </div>
    </div>
  );
}
