"use client";

import { Fire, ShoppingCart } from "@phosphor-icons/react";
import { useSite } from "./store";
import { PlayButton } from "./Player";

export function TrendingList() {
  const { products, openBuy, audioList, currentTrack, playing } = useSite();
  const trending = [...products].sort((a, b) => (b.sold || 0) - (a.sold || 0)).slice(0, 5);
  if (trending.length < 2) return null;

  return (
    <section className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-5 flex items-end justify-between">
        <div>
          <p className="section-eyebrow">Paling Dicari</p>
          <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">
            WHAT&apos;S TRENDING
          </h2>
        </div>
        <span className="badge-chip bg-brand-soft text-brand">
          <Fire size={11} weight="fill" /> HOT LIST
        </span>
      </div>

      <div className="card divide-y divide-line overflow-hidden p-0">
        {trending.map((p, i) => {
          const aIdx = audioList.indexOf(p);
          const isPlaying = aIdx >= 0 && currentTrack === aIdx && playing;
          return (
            <div
              key={p._id}
              className="group flex items-center gap-3 p-3.5 transition hover:bg-w03 md:px-5"
            >
              <span className="w-8 shrink-0 text-center font-poster text-2xl leading-none text-dim transition group-hover:text-brand">
                {String(i + 1).padStart(2, "0")}
              </span>

              <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-line">
                {p.thumbnailUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.thumbnailUrl} alt="" loading="lazy" className="h-full w-full object-cover" />
                ) : (
                  <div className="grid h-full w-full place-items-center bg-elev font-poster text-sm text-dim">
                    {p.title.slice(0, 1)}
                  </div>
                )}
                {isPlaying && (
                  <span className="absolute inset-0 grid place-items-center bg-k60 text-brand">
                    <i className="eq-bar h-3" />
                    <i className="eq-bar h-3" />
                    <i className="eq-bar h-3" />
                  </span>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold">{p.title}</p>
                <p className="text-[10px] font-semibold text-dim">
                  {p.category} · Terjual {p.sold}
                </p>
              </div>

              {aIdx >= 0 && <PlayButton index={aIdx} />}

              <button
                onClick={() => openBuy(p)}
                className="btn btn-dark shrink-0 px-3.5 py-2 text-[11px] hover:!border-brand"
              >
                <ShoppingCart size={13} weight="bold" />
                <span className="hidden sm:inline">Beli</span>
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
}
