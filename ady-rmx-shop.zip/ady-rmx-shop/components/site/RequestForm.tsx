"use client";

import { NotePencil, CaretRight, CheckCircle } from "@phosphor-icons/react";
import { useSite } from "./store";

export function RequestSection() {
  const { settings, openRequest } = useSite();

  return (
    <section id="request" className="mx-auto w-full max-w-6xl scroll-mt-24 px-4 py-14">
      <div className="card overflow-hidden p-0">
        <div className="grid gap-6 p-6 md:grid-cols-[1.3fr_1fr] md:items-center md:p-10">
          <div>
            <p className="section-eyebrow">Custom Order</p>
            <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">
              REQUEST PROJEK
            </h2>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
              Tidak menemukan projek yang cocok? Ajukan request sesuai seleramu —
              pilih kategori dan style, tim kami akan memproses dengan hasil
              berkualitas.
            </p>
            <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs font-bold text-muted">
              <span className="flex items-center gap-1.5">
                <CheckCircle size={15} weight="fill" className="text-brand" />
                Isi detail singkat di form
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle size={15} weight="fill" className="text-brand" />
                Pilih WhatsApp / Telegram
              </span>
            </div>
            <button onClick={openRequest} className="btn btn-primary mt-6 px-8">
              <NotePencil size={16} weight="bold" />
              Request Projek Sekarang
              <CaretRight size={14} weight="bold" />
            </button>
          </div>

          {/* Ilustrasi panel */}
          <div
            className="hidden rounded-3xl border border-line bg-elev p-6 md:block"
            style={{
              backgroundImage:
                "radial-gradient(circle at 80% 20%, var(--glow-soft), transparent 60%)",
            }}
          >
            <div className="space-y-3">
              {[
                { l: "Judul Lagu", v: "Contoh: Karna Ada Ko Enaff..." },
                { l: "Kategori", v: settings.requestCategories[0] || "FLM Full Sample" },
                { l: "Style", v: settings.requestStyles[0] || "Happy Team" },
              ].map((r) => (
                <div key={r.l} className="rounded-xl border border-line bg-card px-4 py-3">
                  <p className="text-[9px] font-bold uppercase tracking-wider text-dim">
                    {r.l}
                  </p>
                  <p className="truncate text-xs font-bold">{r.v}</p>
                </div>
              ))}
              <div className="rounded-xl bg-gradient-to-r from-brand-2 to-brand px-4 py-3 text-center text-xs font-extrabold text-[#14161c]">
                Kirim via WhatsApp / Telegram
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
