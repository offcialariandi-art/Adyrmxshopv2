"use client";

import { ArrowRight, Play, ShoppingCart } from "@phosphor-icons/react";
import { useSite } from "./store";
import { rupiah, discountPercent } from "@/lib/utils";
import type { ProductData } from "./types";

function CarouselCard({ p }: { p: ProductData }) {
  const { openBuy, audioList, currentTrack, playing, playTrack } = useSite();
  const aIdx = audioList.indexOf(p);
  const isPlaying = aIdx >= 0 && currentTrack === aIdx && playing;
  const disc = discountPercent(p);

  return (
    <article className="card card-premium w-44 shrink-0 snap-start overflow-hidden p-0 md:w-52">
      <div className="relative aspect-[3/4] overflow-hidden rounded-t-[19px]">
        {p.thumbnailUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={p.thumbnailUrl}
            alt={p.title}
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 hover:scale-105"
          />
        ) : (
          <div
            className="grid h-full w-full place-items-center"
            style={{
              background:
                "linear-gradient(135deg, #2a2140, #171a2e)",
            }}
          >
            <span className="font-poster text-4xl text-white opacity-20">
              {p.title.slice(0, 2).toUpperCase()}
            </span>
          </div>
        )}

        {disc > 0 && (
          <span className="badge-chip absolute left-2 top-2 bg-rose-500 text-white shadow">
            -{disc}%
          </span>
        )}

        {/* Price chip */}
        <div className="absolute inset-x-2 bottom-2 flex items-center justify-between gap-1.5">
          <span className="rounded-lg border border-brand bg-k70 px-2 py-0.5 font-display text-xs font-bold text-brand backdrop-blur-sm">
            {rupiah(p.price)}
          </span>
          {aIdx >= 0 && (
            <button
              onClick={() => playTrack(aIdx)}
              className={`grid h-8 w-8 place-items-center rounded-full border backdrop-blur-sm transition ${
                isPlaying
                  ? "border-transparent bg-gradient-to-br from-brand-2 to-brand text-[#14161c]"
                  : "border-brand bg-k70 text-brand hover:bg-brand hover:text-[#14161c]"
              }`}
              aria-label="Play sample"
            >
              <Play size={12} weight="fill" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-1.5 p-3">
        <h3 className="truncate text-[13px] font-bold">{p.title}</h3>
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-semibold text-dim">Terjual {p.sold}</span>
          <button
            onClick={() => openBuy(p)}
            className="grid h-7 w-7 place-items-center rounded-full border border-line text-muted transition hover:border-brand hover:text-brand"
            aria-label={"Beli " + p.title}
          >
            <ShoppingCart size={12} weight="bold" />
          </button>
        </div>
      </div>
    </article>
  );
}

export function ProductCarousel() {
  const { products } = useSite();
  const featured = products.slice(0, 10);
  if (!featured.length) return null;

  return (
    <section className="py-8">
      <div className="mx-auto mb-5 flex max-w-6xl items-end justify-between px-4">
        <div>
          <p className="section-eyebrow">Koleksi Terbaru</p>
          <h2 className="mt-2 font-poster text-4xl tracking-wide md:text-5xl">
            PRODUK PREMIUM
          </h2>
        </div>
        <a
          href="#produk"
          className="flex items-center gap-1 text-xs font-bold text-brand transition hover:gap-2"
        >
          Lihat Semua <ArrowRight size={13} weight="bold" />
        </a>
      </div>

      <div className="scroll-x flex snap-x gap-3.5 px-4 pb-2 md:px-[max(1rem,calc((100vw-72rem)/2))]">
        {featured.map((p) => (
          <CarouselCard key={p._id} p={p} />
        ))}
      </div>
    </section>
  );
}
