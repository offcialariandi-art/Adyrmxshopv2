"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  SquaresFour,
  Package,
  Palette,
  AddressBook,
  Chats,
  Question,
  Tray,
  Images,
  ChatCenteredText,
  UserCircle,
  Database,
  List as ListIcon,
  SignOut,
} from "@phosphor-icons/react";

const GROUPS: {
  label: string;
  items: { href: string; label: string; Icon: any }[];
}[] = [
  {
    label: "Utama",
    items: [{ href: "/admin", label: "Dashboard", Icon: SquaresFour }],
  },
  {
    label: "Kelola Toko",
    items: [
      { href: "/admin/products", label: "Produk", Icon: Package },
      { href: "/admin/appearance", label: "Tampilan", Icon: Palette },
      { href: "/admin/contacts", label: "Kontak Order", Icon: AddressBook },
      { href: "/admin/messages", label: "Pesan Template", Icon: ChatCenteredText },
    ],
  },
  {
    label: "Konten",
    items: [
      { href: "/admin/testimonials", label: "Testimoni", Icon: Chats },
      { href: "/admin/faqs", label: "FAQ", Icon: Question },
      { href: "/admin/requests", label: "Request Masuk", Icon: Tray },
      { href: "/admin/media", label: "Media Library", Icon: Images },
    ],
  },
  {
    label: "Sistem",
    items: [
      { href: "/admin/account", label: "Akun Admin", Icon: UserCircle },
      { href: "/admin/backup", label: "Backup & Reset", Icon: Database },
    ],
  },
];

const FLAT = GROUPS.flatMap((g) => g.items);

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [openMenu, setOpenMenu] = useState(false);
  const [reqCount, setReqCount] = useState(0);

  useEffect(() => {
    fetch("/api/admin/requests")
      .then((r) => r.json())
      .then((j) => j.ok && setReqCount(j.baru || 0))
      .catch(() => {});
    setOpenMenu(false);
  }, [pathname]);

  const logout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace("/admin/login");
  };

  const NavBody = ({ onNavigate }: { onNavigate?: () => void }) => (
    <>
      {GROUPS.map((g) => (
        <div key={g.label} className="mb-4">
          <p className="px-3 pb-1.5 text-[9px] font-extrabold uppercase tracking-[0.18em] text-dim">
            {g.label}
          </p>
          {g.items.map(({ href, label, Icon }) => {
            const on =
              href === "/admin" ? pathname === "/admin" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                onClick={onNavigate}
                className={`relative mb-0.5 flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-bold transition ${
                  on
                    ? "bg-brand-soft text-brand"
                    : "text-muted hover:bg-w05 hover:text-ink"
                }`}
              >
                {on && (
                  <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-brand" />
                )}
                <Icon size={16} weight={on ? "fill" : "regular"} />
                <span className="flex-1">{label}</span>
                {href === "/admin/requests" && reqCount > 0 && (
                  <span className="badge-chip !bg-danger-soft !text-rose-400">
                    {reqCount}
                  </span>
                )}
              </Link>
            );
          })}
        </div>
      ))}
    </>
  );

  return (
    <div className="flex min-h-screen">
      {/* Sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-line bg-elev lg:flex">
        <div className="flex items-center gap-3 border-b border-line px-5 py-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo-default.svg"
            alt="logo"
            className="h-9 w-9 rounded-full border border-brand"
          />
          <div>
            <p className="font-display text-sm font-bold leading-tight">Ady RMX</p>
            <p className="text-[9px] font-extrabold uppercase tracking-[0.18em] text-dim">
              Panel Admin
            </p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 pt-4">
          <NavBody />
        </nav>

        <div className="border-t border-line p-3">
          <button
            onClick={logout}
            className="mb-2 flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-bold text-muted transition hover:bg-danger-soft hover:text-rose-400"
          >
            <SignOut size={15} /> Keluar
          </button>
          <p className="px-3 text-[9px] font-semibold text-dim opacity-70">
            v2.0 · Ady RMX Shop
          </p>
        </div>
      </aside>

      {/* Topbar mobile */}
      <header className="fixed inset-x-0 top-0 z-40 flex h-14 items-center justify-between border-b border-line bg-elev px-4 lg:hidden">
        <button
          onClick={() => setOpenMenu(!openMenu)}
          className="grid h-9 w-9 place-items-center rounded-full border border-line"
          aria-label="Menu"
        >
          <ListIcon size={17} />
        </button>
        <div className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/brand/logo-default.svg"
            alt="logo"
            className="h-7 w-7 rounded-full border border-brand"
          />
          <p className="font-display text-sm font-bold">Panel Admin</p>
        </div>
        <button
          onClick={logout}
          className="grid h-9 w-9 place-items-center rounded-full border border-line text-rose-400"
          aria-label="Keluar"
        >
          <SignOut size={15} />
        </button>
      </header>

      {/* Drawer mobile */}
      {openMenu && (
        <div className="fixed inset-0 z-50 lg:hidden" onClick={() => setOpenMenu(false)}>
          <div className="absolute inset-0 bg-k70 anim-fade" />
          <aside
            className="anim-fade absolute inset-y-0 left-0 w-64 overflow-y-auto border-r border-line bg-elev p-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center gap-2.5 px-2 pt-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/brand/logo-default.svg"
                alt="logo"
                className="h-8 w-8 rounded-full border border-brand"
              />
              <p className="font-display text-sm font-bold">Ady RMX Shop</p>
            </div>
            <NavBody onNavigate={() => setOpenMenu(false)} />
          </aside>
        </div>
      )}

      {/* Konten */}
      <main className="min-w-0 flex-1 px-4 pb-16 pt-[72px] lg:pl-[264px] lg:pr-6 lg:pt-6">
        {children}
      </main>
    </div>
  );
}
