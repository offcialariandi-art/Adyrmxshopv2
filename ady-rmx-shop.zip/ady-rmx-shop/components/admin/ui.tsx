"use client";

import React, { useRef, useState } from "react";
import {
  UploadSimple,
  LinkSimple,
  Warning,
  CheckCircle,
  X,
} from "@phosphor-icons/react";

/* ---------- fetch helper ---------- */
export async function api<T = any>(
  path: string,
  opts?: { method?: string; body?: any }
): Promise<T> {
  const res = await fetch(path, {
    method: opts?.method || "GET",
    headers: opts?.body ? { "Content-Type": "application/json" } : undefined,
    body: opts?.body ? JSON.stringify(opts.body) : undefined,
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || j.ok === false) throw new Error(j.error || `HTTP ${res.status}`);
  return j;
}

export function Section({
  title,
  desc,
  children,
}: {
  title: string;
  desc?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="card p-5 md:p-6">
      <div className="mb-4">
        <h2 className="text-sm font-extrabold">{title}</h2>
        {desc && <p className="mt-0.5 text-[11px] text-muted">{desc}</p>}
      </div>
      {children}
    </div>
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint && <p className="mt-1 text-[10px] text-dim">{hint}</p>}
    </div>
  );
}

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="input-wrap">
      <input {...props} className={`input ${props.className || ""}`} />
    </div>
  );
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div className="input-wrap items-start py-2">
      <textarea
        {...props}
        className={`input resize-none ${props.className || ""}`}
      />
    </div>
  );
}

export function Toggle({
  on,
  onChange,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className={`toggle ${on ? "on" : ""}`}
      aria-pressed={on}
    />
  );
}

/* ---------- Media input (upload ATAU URL) ---------- */
const IMG_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const AUD_TYPES = [
  "audio/mpeg", "audio/ogg", "audio/wav", "audio/wave", "audio/x-wav",
  "audio/aac", "audio/mp4",
];
const VID_TYPES = ["video/mp4", "video/webm", "video/quicktime"];

export function MediaInput({
  kind,
  value,
  onChange,
}: {
  kind: "image" | "audio" | "video";
  value: string;
  onChange: (url: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"upload" | "url">("upload");
  const [urlDraft, setUrlDraft] = useState("");

  const upload = async (file: File) => {
    setErr("");
    const allowed =
      kind === "image" ? IMG_TYPES : kind === "video" ? VID_TYPES : AUD_TYPES;
    const okType = allowed.includes(file.type) ||
      (kind === "audio" && file.name.toLowerCase().endsWith(".wav"));
    if (!okType) {
      setErr(
        kind === "image"
          ? "Hanya JPG/PNG/WEBP/GIF."
          : kind === "video"
          ? "Hanya MP4/Webm."
          : "Hanya MP3/OGG/WAV/AAC/M4A."
      );
      return;
    }
    const max = kind === "video" ? 60 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > max) return setErr(kind === "video" ? "Maksimal 60MB." : "Maksimal 10MB.");
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error);
      onChange(j.url);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex gap-1.5">
        <button
          type="button"
          onClick={() => setTab("upload")}
          className={`badge-chip py-1.5 transition ${
            tab === "upload"
              ? "!bg-brand !text-[#14161c]"
              : "border border-line bg-elev text-muted"
          }`}
        >
          <UploadSimple size={11} weight="bold" /> Upload
        </button>
        <button
          type="button"
          onClick={() => setTab("url")}
          className={`badge-chip py-1.5 transition ${
            tab === "url"
              ? "!bg-brand !text-[#14161c]"
              : "border border-line bg-elev text-muted"
          }`}
        >
          <LinkSimple size={11} weight="bold" /> URL
        </button>
      </div>

      {tab === "upload" && (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border border-dashed border-line-strong bg-w04 px-4 py-5 text-xs font-bold text-muted transition hover:border-brand hover:text-brand disabled:opacity-50"
        >
          <UploadSimple size={17} weight="bold" />
          {busy
            ? "Mengunggah..."
            : `Pilih file ${kind === "image" ? "gambar" : "audio"} (maks 10MB)`}
        </button>
      )}
      {tab === "url" && (
        <div className="input-wrap">
          <input
            className="input"
            placeholder="https://..."
            value={urlDraft}
            onChange={(e) => setUrlDraft(e.target.value)}
            onBlur={() => urlDraft.trim() && onChange(urlDraft.trim())}
          />
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        accept={kind === "image" ? "image/*" : kind === "video" ? "video/mp4,video/webm" : "audio/*"}
        className="hidden"
        onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
      />

      {value && (
        <div className="flex items-center gap-3 rounded-2xl border border-line bg-elev p-2.5">
          {kind === "image" ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={value} alt="" className="h-14 w-14 rounded-xl object-cover" />
          ) : kind === "video" ? (
            <video src={value} className="h-14 w-24 rounded-xl object-cover" muted loop autoPlay playsInline />
          ) : (
            <audio src={value} controls preload="none" className="h-9 w-full max-w-[240px]" />
          )}
          <span className="min-w-0 flex-1 truncate font-mono text-[10px] text-dim">
            {value}
          </span>
          <button
            type="button"
            onClick={() => onChange("")}
            className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-line text-dim hover:border-rose-400 hover:text-rose-400"
            aria-label="Hapus media"
          >
            <X size={12} weight="bold" />
          </button>
        </div>
      )}

      {err && (
        <p className="flex items-center gap-1.5 text-[11px] font-bold text-rose-400">
          <Warning size={13} weight="fill" /> {err}
        </p>
      )}
    </div>
  );
}

/* ---------- Modal ---------- */
export function Modal({
  title,
  onClose,
  children,
  wide,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[95] grid place-items-center overflow-y-auto bg-k70 p-4 anim-fade backdrop-blur-sm">
      <div className={`card anim-pop my-8 w-full ${wide ? "max-w-2xl" : "max-w-md"} p-6`}>
        <div className="mb-5 flex items-center justify-between">
          <h3 className="font-display text-lg font-bold">{title}</h3>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-full border border-line text-muted hover:text-ink"
            aria-label="Tutup"
          >
            <X size={13} weight="bold" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------- Notifikasi ---------- */
export function Notice({ msg, ok: isOk }: { msg: string; ok?: boolean }) {
  if (!msg) return null;
  return (
    <p
      className={`mt-3 flex items-center gap-1.5 text-xs font-bold ${
        isOk ? "text-emerald-400" : "text-rose-400"
      }`}
    >
      {isOk ? (
        <CheckCircle size={14} weight="fill" />
      ) : (
        <Warning size={14} weight="fill" />
      )}
      {msg}
    </p>
  );
}

export function confirmDialog(msg: string): boolean {
  return window.confirm(msg);
}

export function ArrowBtns({
  onUp,
  onDown,
  first,
  last,
}: {
  onUp: () => void;
  onDown: () => void;
  first: boolean;
  last: boolean;
}) {
  return (
    <div className="flex flex-col gap-0.5">
      <button
        onClick={onUp}
        disabled={first}
        className="text-[10px] leading-none text-dim transition enabled:hover:text-brand disabled:opacity-25"
        aria-label="Naik"
      >
        ▲
      </button>
      <button
        onClick={onDown}
        disabled={last}
        className="text-[10px] leading-none text-dim transition enabled:hover:text-brand disabled:opacity-25"
        aria-label="Turun"
      >
        ▼
      </button>
    </div>
  );
}
