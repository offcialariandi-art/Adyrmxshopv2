/**
 * Penyimpanan media pluggable.
 *
 * Driver:
 *  - "local" : file ditulis ke folder ./uploads (VPS / Node hosting biasa)
 *  - "db"    : file disimpan di MongoDB collection `media` (Vercel/Netlify/
 *              EdgeOne — filesystem serverless bersifat sementara)
 *  - "auto"  : default. Coba tulis lokal; jika gagal (read-only), fallback DB.
 *
 * Baca file selalu: coba lokal dulu, lalu DB — jadi migrasi antar driver aman.
 */

import { mkdir, readFile, writeFile, unlink, readdir, stat } from "fs/promises";
import path from "path";
import crypto from "crypto";
import mongoose from "mongoose";
import { connectDB } from "./db";

const UPLOAD_DIR = () => path.join(process.cwd(), "uploads");

export type MediaDriver = "local" | "db" | "auto";

export function getDriver(): MediaDriver {
  const v = String(process.env.MEDIA_STORAGE || "auto").toLowerCase();
  return v === "local" || v === "db" ? v : "auto";
}

/** Model dibuat lazy agar aman dipanggil sebelum koneksi awal */
function MediaModel() {
  if (mongoose.models.Media) return mongoose.models.Media;
  const schema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    data: { type: Buffer, required: true },
    size: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now },
  });
  return mongoose.models.Media || mongoose.model("Media", schema);
}

export function randomName(ext: string): string {
  return `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
}

/** Simpan buffer. Return nama file yang bisa diakses via /api/media/<name> */
export async function saveMedia(
  buf: Buffer,
  ext: string
): Promise<{ name: string; driver: MediaDriver }> {
  const driver = getDriver();

  if (driver === "local" || driver === "auto") {
    try {
      const dir = UPLOAD_DIR();
      await mkdir(dir, { recursive: true });
      const name = randomName(ext);
      await writeFile(path.join(dir, name), buf);
      return { name, driver: "local" };
    } catch (e) {
      if (driver === "local") throw e;
      // auto → lanjut simpan ke DB
    }
  }

  await connectDB();
  const name = randomName(ext);
  const Media = MediaModel();
  await Media.create({ name, data: buf, size: buf.length });
  return { name, driver: "db" };
}

/** Baca file: lokal dulu, lalu DB */
export async function readMedia(
  name: string
): Promise<{ buf: Buffer } | null> {
  if (!/^[A-Za-z0-9._-]+$/.test(name)) return null;

  // 1) Lokal
  try {
    const fp = path.join(UPLOAD_DIR(), name);
    await stat(fp);
    const buf = await readFile(fp);
    if (buf.length > 0) return { buf };
  } catch {}

  // 2) Database
  try {
    await connectDB();
    const Media = MediaModel();
    const doc = await Media.findOne({ name }).lean();
    if (doc?.data) return { buf: Buffer.from(doc.data as Buffer) };
  } catch {}

  return null;
}

/** Hapus dari lokal DAN database (jika ada) */
export async function deleteMedia(name: string): Promise<void> {
  if (!/^[A-Za-z0-9._-]+$/.test(name)) return;
  try {
    await unlink(path.join(UPLOAD_DIR(), name));
  } catch {}
  try {
    const Media = MediaModel();
    await Media.deleteMany({ name });
  } catch {}
}

export interface MediaItem {
  name: string;
  url: string;
  size: number;
  isAudio: boolean;
  isVideo: boolean;
  source: "local" | "db";
  modified: Date;
}

/** Gabungan file lokal + entri DB */
export async function listMedia(): Promise<MediaItem[]> {
  const items = new Map<string, MediaItem>();
  const kindOf = (name: string) => ({
    isAudio: /\.(mp3|ogg|wav|aac|m4a)$/i.test(name),
    isVideo: /\.(mp4|webm|mov)$/i.test(name),
  });

  // Lokal
  try {
    const names = await readdir(UPLOAD_DIR());
    for (const name of names) {
      try {
        const s = await stat(path.join(UPLOAD_DIR(), name));
        if (!s.isFile()) continue;
        items.set(name, {
          name,
          url: `/api/media/${name}`,
          size: s.size,
          ...kindOf(name),
          source: "local",
          modified: s.mtime,
        });
      } catch {}
    }
  } catch {}

  // Database (yang belum ada di lokal)
  try {
    await connectDB();
    const Media = MediaModel();
    const docs = await Media.find({}, { name: 1, size: 1, createdAt: 1 }).lean();
    for (const d of docs as any[]) {
      if (items.has(d.name)) continue;
      const size = Number(d.size) || 0;
      items.set(d.name, {
        name: d.name,
        url: `/api/media/${d.name}`,
        size,
        ...kindOf(d.name),
        source: "db",
        modified: d.createdAt || new Date(0),
      });
    }
  } catch {}

  return [...items.values()].sort(
    (a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime()
  );
}

