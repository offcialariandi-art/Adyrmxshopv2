import bcrypt from "bcryptjs";
import { connectDB } from "./db";
import { Setting, Testimonial } from "../models";

let seeded = false;

/** Pastikan dokumen setting + akun admin default sudah ada + migrasi ringan */
export async function ensureSeed() {
  if (seeded) return Setting.findOne({ key: "main" });
  await connectDB();

  let doc = await Setting.findOne({ key: "main" });
  if (!doc) {
    doc = await Setting.create({
      key: "main",
      adminUser: "ady",
      adminHash: bcrypt.hashSync("ady123", 10),
    });
  }
  if (!doc.adminHash) {
    doc.adminHash = bcrypt.hashSync("ady123", 10);
    await doc.save();
  }

  // Migrasi: sosmed lama (string URL) → array socials
  if (!doc.socials || doc.socials.length === 0) {
    const legacy = (
      [
        ["instagram", "Instagram", (doc as any).instagram],
        ["tiktok", "TikTok", (doc as any).tiktok],
        ["youtube", "YouTube", (doc as any).youtube],
        ["facebook", "Facebook", (doc as any).facebook],
      ] as [string, string, string][]
    ).filter(([, , url]) => !!url);
    if (legacy.length) {
      doc.socials = legacy.map(([key, label, url]) => ({ key, label, url, active: true }));
      await doc.save();
    }
  }

  // Migrasi: testimoni lama tanpa status → approved
  await Testimonial.updateMany(
    { status: { $exists: false } },
    { $set: { status: "approved" } }
  );

  seeded = true;
  return Setting.findOne({ key: "main" });
}

/** Settings aman untuk publik (tanpa kredensial admin) */
export async function getPublicSettings() {
  const doc = await ensureSeed();
  const o = doc!.toObject();
  delete (o as any).adminHash;
  delete (o as any).adminUser;
  return o;
}
