export const rupiah = (n: number) =>
  "Rp " + new Intl.NumberFormat("id-ID").format(Math.max(0, Math.round(n || 0)));

export function normalizeWa(v: string) {
  return String(v || "").replace(/[^0-9]/g, "");
}

export function buildWaLink(number: string, message: string) {
  return `https://wa.me/${normalizeWa(number)}?text=${encodeURIComponent(message)}`;
}

export function buildTgLink(username: string) {
  const u = String(username || "").replace(/^@/, "").trim();
  return `https://t.me/${u}`;
}

/** Ganti placeholder {store} {produk} {harga} {nama} {catatan} {kategori} {style} */
export function renderTemplate(
  tpl: string,
  data: Record<string, string | number>
): string {
  return String(tpl || "").replace(/\{(\w+)\}/g, (_, k: string) => {
    if (k === "catatan") return data.catatan ? `\nCatatan: ${data.catatan}` : "";
    const v = data[k];
    return v !== undefined && v !== null ? String(v) : `{${k}}`;
  });
}

export function badgeFor(p: any): string {
  if (p.badge) return p.badge;
  const created = p.createdAt ? new Date(p.createdAt).getTime() : 0;
  if (created && Date.now() - created < 7 * 864e5) return "NEW";
  if ((p.sold || 0) >= 20) return "HOT";
  return "";
}

export function discountPercent(p: any): number {
  if (p.oldPrice && p.oldPrice > p.price)
    return Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
  return 0;
}
