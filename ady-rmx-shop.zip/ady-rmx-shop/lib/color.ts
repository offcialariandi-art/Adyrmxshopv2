/** Util warna murni JS — hasil nilai konkret hex/rgba (tanpa color-mix CSS) */

export function hexToRgb(hex: string): [number, number, number] {
  let h = String(hex || "").replace("#", "").trim();
  if (h.length === 3)
    h = h
      .split("")
      .map((c) => c + c)
      .join("");
  const n = parseInt(h.slice(0, 6) || "000000", 16);
  if (isNaN(n)) return [0, 0, 0];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
const toHex = (v: number) => clamp(v).toString(16).padStart(2, "0");

export function mix(a: string, b: string, ratioB: number): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return `#${toHex(r1 + (r2 - r1) * ratioB)}${toHex(g1 + (g2 - g1) * ratioB)}${toHex(
    b1 + (b2 - b1) * ratioB
  )}`;
}

export function rgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

const isHex = (v?: string) => !!v && /^#[0-9a-fA-F]{6}$/.test(v);

/** Semua variabel tema turunan — nilai konkret siap inject ke <html style> */
export function themeVars(accentRaw?: string, bgRaw?: string): Record<string, string> {
  const brand = isHex(accentRaw) ? accentRaw! : "#00e5b0";
  const bg = isHex(bgRaw) ? bgRaw! : "#060607";
  const card = mix(bg, "#ffffff", 0.05);

  return {
    "--brand": brand,
    "--brand-2": mix(brand, "#ffffff", 0.55),
    "--brand-dark": mix(brand, "#000000", 0.35),
    "--brand-soft": rgba(brand, 0.12),
    "--glow": rgba(brand, 0.18),
    "--glow-soft": rgba(brand, 0.06),
    "--ring": rgba(brand, 0.25),
    "--bg-base": bg,
    "--bg-elev": mix(bg, "#ffffff", 0.055),
    "--bg-card": card,
    "--glass-bg": rgba(mix(bg, "#ffffff", 0.04), 0.82),
    "--glass-strong": rgba(mix(bg, "#ffffff", 0.06), 0.96),
    "--input-bg": mix(bg, "#ffffff", 0.04),
    "--line": mix(bg, "#ffffff", 0.115),
    "--line-strong": mix(bg, "#ffffff", 0.22),
  };
}
