import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/adyrmx";

let cached = (global as any)._mongoConn;

export async function connectDB() {
  if (cached?.state === 1) return cached;
  mongoose.set("strictQuery", true);
  cached = await mongoose.connect(MONGODB_URI);
  return cached;
}
