# 🎵 ADY RMX SHOP

Website jualan projek sound / FLM (FL Studio Mobile) dengan **sample audio preview**,
**order manual via WhatsApp/Telegram**, **panel admin lengkap**, dan tema gelap premium
("Obsidian Mint").

Dukungan hosting: ✅ **VPS** · ✅ **Vercel** · ✅ **Netlify** · ✅ **EdgeOne Pages** · ✅ **Railway/Render**

---

## ✨ Fitur

- Landing page: hero + search, carousel produk, kartu demo MIX|REMIX, trending,
  testimoni (user kirim → admin approve), request projek via bottom-sheet WA/TG, FAQ
- Order: multi kontak WA/TG (1 kontak = langsung buka; ≥2 = bottom sheet pilihan)
- Admin (`/admin`): CRUD produk (+trash/restore), tampilan & tema warna,
  background gambar/video, kontak order, testimoni, FAQ, request masuk,
  media library, template pesan, ganti password, backup/restore JSON
- Media upload: **gambar/audio/video** — otomatis pilih penyimpanan disk lokal
  atau MongoDB (untuk hosting serverless)

---

## 📦 Struktur Project

```
├─ app/                 # Next.js App Router (halaman + API)
│  ├─ page.tsx          # Landing page
│  ├─ admin/            # Panel admin (login + panel)
│  └─ api/              # API admin & publik + serve media
├─ components/          # Komponen site & admin
├─ lib/                 # db, auth (JWT), settings, media driver, utils
├─ models/              # Schema Mongoose
├─ middleware.ts        # Proteksi route /admin & /api/admin
├─ uploads/             # Media saat driver "local" (kosongkan isinya di repo)
├─ public/brand/        # Logo & banner default SVG
└─ ecosystem.config.cjs # Konfigurasi PM2 (untuk VPS)
```

---

## 🔑 Kredensial Default

| | |
|---|---|
| URL Admin | `https://domainmu.com/admin` |
| Username | `ady` |
| Password | `ady123` |

> ⚠️ **Wajib ganti** setelah login pertama di menu **Akun**.

---

## 🗄️ Langkah 0 — Database (MongoDB Atlas Gratis)

Semua metode hosting butuh database. Paling mudah pakai **Atlas M0 (gratis selamanya)**:

1. Daftar di <https://www.mongodb.com/cloud/atlas> → Create Cluster (M0 Free)
2. **Database Access** → Add New Database User
   - Username/password (simpan!) · Role: *Read and write*
3. **Network Access** → Add IP Address → `0.0.0.0/0` (Allow from anywhere)
4. **Connect → Drivers → Node.js** → salin URI, contoh:
   ```
   mongodb+srv://user:password@cluster0.xxxxx.mongodb.net/adyrmx?retryWrites=true&w=majority
   ```
   (nama DB `adyrmx` dibuat otomatis)

---

## 🔐 Environment Variables

Salin `.env.example` → `.env.local`, isi:

| Variabel | Wajib | Keterangan |
|---|---|---|
| `MONGODB_URI` | ✅ | URI Atlas / localhost |
| `ADMIN_SECRET` | ✅ | String acak ≥32 karakter (kunci JWT) |
| `MEDIA_STORAGE` | – | `auto` (default) · `local` (VPS) · `db` (serverless) |
| `PORT` | – | Port `npm start` (default 3000) |

Generate `ADMIN_SECRET`:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## ▲ Deploy ke Vercel (Gratis)

1. Push project ini ke **GitHub** (tanpa folder `node_modules`, `.next`,
   isi `uploads/`, dan `.env.local` — sudah difilter `.gitignore`)
2. <https://vercel.com> → **Add New → Project** → pilih repo → Import
   (Framework otomatis terdeteksi: Next.js)
3. **Environment Variables** → tambah:
   - `MONGODB_URI` = URI Atlas kamu
   - `ADMIN_SECRET` = string acak
   - `MEDIA_STORAGE` = `db`
4. **Deploy** → selesai (~2 menit). Domain gratis: `nama.vercel.app`
5. Login `/admin` → ganti password → isi produk & kontak

**Catatan penting Vercel:**
- Limit body request ±4.5MB → upload media besar via input **URL**
  (Google Drive direct link, Cloudinary gratis, dll) atau file ≤4MB
- File yang diupload tersimpan di MongoDB (`MEDIA_STORAGE=db`), maks ±12MB/file
- Video background 60MB hanya untuk VPS (pakai video dari URL eksternal di Vercel)

## 🌐 Deploy ke Netlify

1. Netlify → **Add new site → Import existing project** → pilih repo GitHub
2. Build command: `npm run build` · Publish: otomatis (plugin Next.js terpasang sendiri)
3. **Site settings → Environment variables** → sama seperti Vercel
4. Deploy

## ☁️ Deploy ke EdgeOne Pages (Tencent)

1. <https://edgeone.ai/products/pages> → login → **Create Project**
2. Pilih **Import from Git** → authorize GitHub → pilih repo
3. Framework preset: **Next.js** · Build: `npm run build`
4. Tambahkan Environment Variables (sama seperti atas, `MEDIA_STORAGE=db`)
5. Deploy → dapat domain `*.edgeone.app`

> Jika EdgeOne menanyakan output directory biarkan default deteksi otomatis.
> Alternatif tanpa Git: Build di Vercel dulu lalu arahkan domain, atau gunakan
> CLI `edgeone pages deploy ./ -n ady-rmx`.

## 🚄 Deploy ke Railway / Render

Keduanya mendukung Next.js + persistent disk:

1. New Project → Deploy from GitHub repo
2. Env vars sama seperti atas (`MEDIA_STORAGE` boleh `auto`/`db`)
3. Railway: tambahkan plugin **MongoDB** bila tidak mau Atlas
4. Start command: `npm start`

---

## 🖥️ Deploy di VPS (Ubuntu)

### 1. Instal dependensi
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs nginx mongodb-org git
# MongoDB instalasi lengkap: https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-ubuntu/
sudo systemctl enable --now mongod
sudo npm i -g pm2
```

### 2. Upload project
Salin `ady-rmx-shop-src.zip` ke server (scp/SFTP), lalu:
```bash
cd /root && unzip ady-rmx-shop-src.zip && cd ady-rmx-shop
cp .env.example .env.local
nano .env.local    # isi MONGODB_URI=localhost, ADMIN_SECRET acak, MEDIA_STORAGE=local
npm install
npm run build
```

### 3. Jalankan dengan PM2
```bash
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup    # auto-start saat reboot
```

### 4. Nginx reverse proxy + SSL
```bash
sudo nano /etc/nginx/sites-available/toko
```
```nginx
server {
    listen 80;
    server_name domainmu.com;
    client_max_body_size 80m;

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;

    location / {
        proxy_pass http://127.0.0.1:8300;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
```bash
sudo ln -s /etc/nginx/sites-available/toko /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d domainmu.com     # SSL gratis + redirect otomatis
```

### 5. Update aplikasi di kemudian hari
```bash
cd /root/ady-rmx-shop
# timpa file source baru (jangan hapus uploads/, .env.local, node_modules/)
npm install && npm run build && pm2 restart ady-rmx-shop
```

---

## ⚙️ Perbandingan Penyimpanan Media

| Hosting | `MEDIA_STORAGE` | Maks file | Catatan |
|---|---|---|---|
| VPS | `local` / `auto` | Video 60MB | Paling bebas & cepat |
| Vercel | `db` | ±4.5MB (limit platform) | File besar → input URL |
| Netlify | `db` | Serupa Vercel | Idem |
| EdgeOne | `db` | Ikut limit fungsi | Idem |

File tetap dilayani lewat URL yang sama: `/api/media/<nama>` — aman dipindah-
pindahkan karena pembacaan selalu cek disk dulu lalu database.

---

## 🧯 Troubleshooting

| Masalah | Solusi |
|---|---|
| Build gagal saat unduh font Google | Ulangi build (jaringan); atau sementara ganti koneksi |
| `MongooseServerSelectionError` di Atlas | Cek Network Access `0.0.0.0/0` & password user |
| Login admin ditolak terus | Hapus cookie situs; cek `ADMIN_SECRET` tidak berubah-ubah |
| Lupa password admin | VPS: `mongosh adyrmx` → `db.settings.updateOne({key:"main"},{$set:{adminHash:""}})` lalu login `ady/ady123` |
| Upload gagal di Vercel | Batas 4.5MB/request — pakai input URL untuk file besar |
| Gambar lama hilang setelah migrasi hosting | Media driver `local` tersimpan di disk VPS; copy folder `uploads/` ke server baru |

---

## 📜 Lisensi

Bebas digunakan & dimodifikasi untuk kebutuhan tokomu. Crafted with precision.
